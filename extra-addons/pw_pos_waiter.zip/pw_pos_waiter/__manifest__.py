# -*- coding: utf-8 -*-
{
    'name': 'POS Waiter',
    'version': '1.0',
    'author': 'Preway IT Solutions',
    'category': 'Point of Sale',
    'depends': ['point_of_sale', 'pos_hr'],
    'summary': 'This apps helps you set waiter on pos order from pos screen | POS Order Waiter | Assign waiter on POS',
    'description': """
- Odoo POS Order Waiter
- Odoo POS Order salesperson
- Odoo POS Order line user
    """,
    'data': [
        'views/pos_config_view.xml',
        'views/hr_employee_view.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'pw_pos_waiter/static/src/js/models.js',
            'pw_pos_waiter/static/src/js/ProductScreen.js',
            'pw_pos_waiter/static/src/js/WaiterButton.js',
            'pw_pos_waiter/static/src/xml/**/*',
        ],
    },
    'price': 15.0,
    'currency': "EUR",
    'application': True,
    'installable': True,
    "license": "LGPL-3",
    "images":["static/description/Banner.png"],
}
