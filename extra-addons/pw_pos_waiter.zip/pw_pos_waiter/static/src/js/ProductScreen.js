/** @odoo-module */
import { patch } from "@web/core/utils/patch";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { _t } from "@web/core/l10n/translation";
import { Order } from "@point_of_sale/app/store/models";


patch(Order.prototype, {
    async pay() {
        var order = this.pos.get_order();
        if(this.pos.config.allow_waiter && this.pos.config.waiter_required && !order.get_order_waiter()){
            this.env.services.popup.add(ErrorPopup, {
                title: _t("Waiter Required"),
                body: _t("Please set waiter on order."),
            });
        } else {
            return super.pay(...arguments);
        }
    },
});
