/** @odoo-module **/


import { Order } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(Order.prototype, {
    setup(_defaultObj, options) {
        super.setup(...arguments);
        this.waiter_id = this.waiter_id || "";
    },
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        if (this.waiter_id) {
            json.waiter_id = this.waiter_id;
        }
        return json;
    },
    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        if (json.waiter_id) {
            this.waiter_id = json.waiter_id
        }
    },
    get_order_waiter_by_id(waiter_id) {
        var self = this;
        var emp = null;
        for (var i = 0; i < self.pos.employees.length; i++) {
            if (self.pos.employees[i].id == waiter_id) {
                emp = self.pos.employees[i];
            }
        }
        return emp;
    },
    set_order_waiter(waiter_id) {
        this.waiter_id = waiter_id.id;
    },
    get_order_waiter() {
        return this.get_order_waiter_by_id(this.waiter_id);
    },
    export_for_printing() {
        var receipt = super.export_for_printing(...arguments);
        if(this.waiter_id){
            receipt['headerData']['waiter_id'] = this.get_order_waiter();
        }
        return receipt;
    },
});
