/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { useService } from "@web/core/utils/hooks";
import { NumberPopup } from "@point_of_sale/app/utils/input_popups/number_popup";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { Component } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { SelectionPopup } from "@point_of_sale/app/utils/input_popups/selection_popup";


export class WaiterButton extends Component {
    static template = "pw_pos_waiter.WaiterButton";

    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
    }
    get order_waiter() {
        var order = this.pos.get_order();
        var waiter = order.get_order_waiter();
        return waiter ? waiter.name : '';
    }
    async click() {
        const selectionList = this.pos.employees.filter((employee) => employee.is_waiter == true).map(emp => ({
            id: emp.id,
            label: emp.name,
            item: emp,
        }));
        const { confirmed, payload: selectedEmp } = await this.popup.add(
            SelectionPopup,
            {
                title: _t("Select Waiter"),
                list: selectionList,
            }
        );
        if (confirmed) {
            const order = this.pos.get_order();
            order.set_order_waiter(selectedEmp);
        }
    }
}

ProductScreen.addControlButton({
    component: WaiterButton,
    condition: function () {
        return this.pos.config.allow_waiter;
    },
});
