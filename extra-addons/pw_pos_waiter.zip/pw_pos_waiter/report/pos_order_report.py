# -*- coding: utf-8 -*-
from odoo import models, fields


class PosOrderReport(models.Model):
    _inherit = "report.pos.order"

    waiter_id = fields.Many2one('hr.employee', string='Waiter', readonly=True)

    def _select(self):
        return super(PosOrderReport, self)._select() + ', s.waiter_id AS waiter_id'

    def _group_by(self):
        return super(PosOrderReport, self)._group_by() + ',s.waiter_id'
