# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HrEmployeeBase(models.AbstractModel):
    _inherit = 'hr.employee.base'

    is_waiter = fields.Boolean('Is Waiter')
