# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PosConfig(models.Model):
    _inherit = 'pos.config'

    allow_waiter = fields.Boolean('Allow Waiter')
    waiter_required = fields.Boolean('Waiter Mandatory')

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    allow_waiter = fields.Boolean(related='pos_config_id.allow_waiter',readonly=False)
    waiter_required = fields.Boolean(related='pos_config_id.waiter_required',readonly=False)

class PosSessions(models.Model):
    _inherit = 'pos.session'

    def _loader_params_hr_employee(self):
        result = super()._loader_params_hr_employee()
        result['search_params']['fields'].append('is_waiter')
        return result
