# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class PosOrder(models.Model):
    _inherit = 'pos.order'

    waiter_id = fields.Many2one('hr.employee', string='Waiter')

    @api.model
    def _order_fields(self, ui_order):
        order_fields = super(PosOrder, self)._order_fields(ui_order)
        order_fields['waiter_id'] = ui_order.get('waiter_id')
        return order_fields

class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    waiter_id = fields.Many2one('hr.employee', string='Waiter')
