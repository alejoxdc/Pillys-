from . import medical_inpatient
