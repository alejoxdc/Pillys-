from . import medical_genetics
