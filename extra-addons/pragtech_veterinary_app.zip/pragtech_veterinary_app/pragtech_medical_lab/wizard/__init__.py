# -*- coding: utf-8 -*-

from . import wizard_multiple_test_request
from . import wizard_create_lab_test
