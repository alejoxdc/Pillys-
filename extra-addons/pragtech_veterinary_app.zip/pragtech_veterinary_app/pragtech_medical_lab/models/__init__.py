from . import medical_lab
