from . import medical_gyneco
