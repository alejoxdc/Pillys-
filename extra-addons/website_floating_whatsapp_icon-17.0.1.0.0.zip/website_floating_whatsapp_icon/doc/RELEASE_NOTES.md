## Module <website_floating_whatsapp_icon>

#### 08.04.2024
#### Version 17.0.1.0.0
#### ADD
Initial Commit for WhatsApp Floating Icon in Website
