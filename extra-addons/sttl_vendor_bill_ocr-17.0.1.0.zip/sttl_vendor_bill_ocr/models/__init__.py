# -*- coding: utf-8 -*-

from . import res_config_settings
from . import account_move
from . import account_journal
from . import ir_attachment
from . import purchase_order_line
