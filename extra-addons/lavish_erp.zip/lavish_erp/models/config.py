from odoo.tools import config

#config['limit_time_real'] = None
#config['limit_time_cpu'] = None
#config['limit_time_real_cron'] = None