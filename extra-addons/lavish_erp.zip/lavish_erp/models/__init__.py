# -*- coding: utf-8 -*-

from . import base
from . import product_category 
from . import res_branch 
from . import cities 
from . import account_journal 
from . import general_parameters 
from . import account_tax_group 
from . import account_move
from . import employees_parameters
from . import model_respartner 
from . import res_users 
from . import model_alerts