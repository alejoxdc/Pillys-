/** @odoo-module */

import { NotificationItem } from "@mail/core/web/notification_item";

NotificationItem.props = [...NotificationItem.props, "threadType?","whatsappPartnerName?"];