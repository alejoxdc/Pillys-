# 🔒 Módulo: Backup Automático SSH/SCP para Odoo 17

## 📋 Descripción General

Sistema profesional de backup automatizado para Odoo 17 que permite:
- **Backups locales** descargables vía HTTP
- **Backups remotos** a servidores SSH/SCP
- **Soporte multi-formato** (ZIP completo o SQL ligero)
- **Bases de datos grandes** hasta 2GB+
- **Automatización por cron** (cada 8 horas, diario, manual)
- **Seguridad robusta** con autenticación SSH y validación binaria

---

## 🚀 Requisitos Previos

### En el servidor local (donde instalarás el módulo)

**Software requerido:**
```bash
# Herramientas de red y transferencia
sudo apt-get install curl sshpass openssh-client -y

# Python 3.10+ (ya incluido en Odoo 17)
python3 --version

# PostgreSQL client (para backups SQL opcionales)
sudo apt-get install postgresql-client -y
```

### En el servidor remoto (destino de backups SSH)

**Software requerido:**
```bash
# SSH Server
sudo apt-get install openssh-server -y

# Espacio en disco: mínimo 2-3x el tamaño de la BD
# Ejemplo: BD de 800MB requiere 2.4GB de espacio
df -h  # Verificar espacio disponible
```

---

## 📦 Instalación del Módulo

### Paso 1: Verificar dependencias

```bash
# En el servidor local
which curl
which sshpass
which ssh

# Todos deben estar disponibles
```

### Paso 2: Instalar en Odoo

1. **Reinicia Odoo** para que detecte el nuevo módulo:
   ```bash
   pkill -f odoo-bin
   ./odoo-bin -c odoo.conf
   ```

2. **En la interfaz de Odoo**:
   - Ve a `Administración` → `Módulos`
   - Busca `backup_auto_scp`
   - Clic en el módulo
   - Botón **"Instalar"** (o **"Actualizar"** si ya estaba instalado)

### Paso 3: Verificar instalación

```bash
# Ver en los logs de Odoo
tail -20 /var/log/odoo/odoo.log
# Debe mostrar mencionado el módulo
```

---

## ⚙️ Configuración Paso a Paso

### Paso 1: Acceder a la configuración

1. En Odoo: `Menú` → buscar **"Backup Automático"**
2. O: `Aplicaciones` → `Backup Automático`
3. Crear una nueva configuración

### Paso 2: Sección "CONFIGURACIÓN BASE DE DATOS"

| Campo | Ejemplo | Descripción |
|-------|---------|-------------|
| **Base de Datos** | `admin` | Nombre de la BD a respaldar |
| **Frecuencia** | `Diario` | `8_hours` / `daily` / `manual` |
| **Modo de Backup** | `Enviar a Servidor SSH` | Dónde guardar el backup |
| **Formato de Descarga** | `Completo (ZIP)` | `zip` o `sql` |

### Paso 3: Sección "CONFIGURACIÓN ODOO LOCAL"

**Para respaldar Odoo LOCAL (mismo servidor):**

```yaml
Host Odoo Local:        localhost
Puerto Odoo Local:      8069
Master Password:        admin_password  # Del odoo.conf local
```

**Para respaldar Odoo REMOTO (otro servidor):**

```yaml
Host Odoo Local:        157.180.32.7     # IP del servidor remoto
Puerto Odoo Local:      8069             # Puerto del Odoo remoto
Master Password:        C+UQYz9OKihLWPSZ # Contraseña del Odoo remoto
```

**⚠️ IMPORTANTE - Proxy Mode:**

Si el Odoo remoto tiene `proxy_mode = True`:

```bash
# En el servidor remoto, editar odoo.conf
cat /etc/odoo.conf | grep proxy_mode

# Si dice "proxy_mode = True", cambiar a:
# proxy_mode = False
# Reiniciar Odoo
sudo systemctl restart odoo
```

### Paso 4: Sección "CONFIGURACIÓN SERVIDOR SSH"

| Campo | Ejemplo | Descripción |
|-------|---------|-------------|
| **Servidor SSH** | `157.180.32.7` | IP del servidor de destino |
| **Usuario SSH** | `backup_user` | Usuario SSH creado |
| **Password SSH** | `mi_contraseña` | Contraseña SSH (o vacío si usas clave) |
| **Ruta en Servidor** | `/home/backup_user/backups` | Directorio para guardar |
| **Ruta Clave SSH** | `/root/.ssh/id_rsa_backup` | Clave SSH (si no usas contraseña) |

**Crear usuario de backup en el servidor remoto:**

```bash
# En el servidor remoto (SSH)
sudo useradd -m -s /bin/bash backup_user
sudo mkdir -p /home/backup_user/backups
sudo chown backup_user:backup_user /home/backup_user/backups
sudo chmod 700 /home/backup_user/backups

# Establecer contraseña
sudo passwd backup_user
```

---

## 🔐 Autenticación SSH: Dos Opciones

### Opción A: Contraseña SSH (Más simple)

```yaml
Servidor SSH:       157.180.32.7
Usuario SSH:        backup_user
Contraseña SSH:     tu_contraseña_aqui
Ruta Clave SSH:     [VACÍO - dejar en blanco]
```

**Requisitos:**
- `sshpass` instalado en servidor local
- Contraseña correcta

### Opción B: Clave SSH (Más seguro - RECOMENDADO)

```yaml
Servidor SSH:       157.180.32.7
Usuario SSH:        backup_user
Contraseña SSH:     [VACÍO - dejar en blanco]
Ruta Clave SSH:     /root/.ssh/id_rsa_backup
```

**Configuración:**

```bash
# En el servidor Odoo local
sudo mkdir -p /root/.ssh
sudo ssh-keygen -t rsa -N "" -f /root/.ssh/id_rsa_backup

# Copiar clave pública al servidor remoto
cat /root/.ssh/id_rsa_backup.pub | ssh backup_user@157.180.32.7 'cat >> ~/.ssh/authorized_keys'

# Verificar conectividad
ssh -i /root/.ssh/id_rsa_backup backup_user@157.180.32.7 'ls -la /home/backup_user/backups'
```

---

## 🧪 Pruebas de Configuración

### Test 1: Conectividad Odoo

```bash
# En terminal del servidor Odoo local
curl -X POST \
  -d "master_pwd=admin_password&name=admin&backup_format=zip" \
  "http://localhost:8069/web/database/backup" \
  -o /tmp/test.zip -v

# Resultado esperado: Archivo de 1MB+
# Si descarga HTML con "Access Denied": contraseña incorrecta
```

### Test 2: Conectividad SSH

```bash
# Con contraseña
sshpass -p "contraseña" ssh -o StrictHostKeyChecking=no \
  backup_user@157.180.32.7 "ls -la /home/backup_user/backups"

# O con clave SSH
ssh -i /root/.ssh/id_rsa_backup backup_user@157.180.32.7 "ls -la /home/backup_user/backups"
```

### Test 3: En Odoo

- Botón: **"🔗 Probar Conexión"**
- Debe mostrar: ✅ **Conexión exitosa**

---

## 🎯 Uso del Módulo

### Descargar backup local

1. Botón: **"⬇️ Descargar Backup"**
2. Se descargará un archivo ZIP

### Enviar backup a SSH

1. Verificar configuración SSH correcta
2. Botón: **"📤 Enviar a SSH"**
3. Esperar (30 min a 2 horas según BD)
4. Verificar en servidor remoto:
   ```bash
   ssh backup_user@157.180.32.7 "ls -lh /home/backup_user/backups/"
   ```

### Backup manual

- Botón: **"⚙️ Backup Manual"**

### Automatizado

- `Frecuencia`: `Diario` o `8 Horas`
- Botón: **"▶️ Activar"**
- El sistema hará backups automáticamente

---

## 📊 Estadísticas

El módulo registra:

| Campo | Descripción |
|-------|-------------|
| **Total de Backups** | Contador total |
| **Último Backup** | Fecha y hora |
| **Tamaño del Último** | MB/GB |
| **Archivo Creado** | Nombre del archivo |
| **Resultado** | Éxito o error |

---

## 🚀 Características Avanzadas

### Timeouts configurables

Para bases de datos MUY grandes (1GB+):

Editar `models/backup_auto_scp.py`:

```python
# Línea ~250
'--max-time', '7200',  # Cambiar a 7200 (120 minutos)
```

### Logging detallado

Los logs muestran:
- 📥 Descarga iniciada
- ✅ Validación ZIP
- 📤 Transferencia SSH
- ❌ Errores con detalles

```bash
# Ver logs
tail -f /var/log/odoo/odoo.log | grep -E "📥|📤|✅|❌"
```

---

## 🔍 Troubleshooting

### Error: "Access Denied"

```bash
# Verificar contraseña
cat /etc/odoo.conf | grep admin_passwd

# Cambiar contraseña en Odoo
# Administración → Parámetros del Sistema → system.admin_password
```

### Error: "Connection refused" SSH

```bash
# Verificar SSH
ssh -v backup_user@157.180.32.7

# Habilitar puerto 22
sudo ufw allow 22/tcp
```

### Error: "Permission denied" SSH

```bash
# En servidor remoto
sudo chmod 700 /home/backup_user/backups
sudo chown backup_user:backup_user /home/backup_user/backups
```

### Error: "utf-8 codec can't decode"

Versión antigua. Actualizar:
- `Administración` → `Módulos` → `backup_auto_scp` → **Actualizar**

---

## 📈 Rendimiento

| Parámetro | Valor | Notas |
|-----------|-------|-------|
| **Tamaño máximo BD** | 2GB+ | Con timeout 120min |
| **Tiempo descarga** | 60 min | 800MB típico |
| **Tiempo SSH** | 60 min | 800MB en conexión normal |
| **Compresión** | ~60% original | Datos Odoo |

---

## 📝 Archivos del Módulo

```
backup_auto_scp/
├── __manifest__.py                 # Metadatos
├── __init__.py                     # Inicialización
├── models/backup_auto_scp.py       # Lógica principal
├── controllers/backup_controller.py # Endpoint HTTP
├── views/backup_auto_scp_views.xml # Interfaz
├── security/ir.model.access.csv    # Permisos
└── README.md                       # Este archivo
```

---

## ✨ Versión

**v1.0** - 23 Diciembre 2025
- ✅ Backup local ZIP
- ✅ Transferencia SSH/SCP
- ✅ Soporte 700+MB
- ✅ Cron automático
- ✅ Logging completo

### Monitorear Backups
- Ver **estadísticas** en tiempo real
- **Próximo backup programado**
- **Resultado del último backup**
- **Tamaño de archivos** generados

## 🔧 Configuración Técnica

### Servidor de destino por defecto
```
Host: 5.78.131.185
Usuario: root  
Password: xApgsicXgqmX
Ruta: /home/a.fecol.digital/odoo17/backups/
```

### Cron automático
El módulo instala un cron que se ejecuta **cada 8 horas** y busca configuraciones activas para procesar automáticamente.

## 🛡️ Seguridad

- ✅ **Autenticación SSH automática** sin prompts interactivos
- ✅ **Creación automática** de directorios remotos
- ✅ **Validación de conexión** antes del envío
- ✅ **Logs detallados** para troubleshooting
- ✅ **No almacena archivos localmente** (ahorro de espacio)

## 📝 Archivos generados

Los backups se guardan con el formato:
```
backup_[database]_YYYY-MM-DD_HH-MM-SS.zip
```

Ejemplo:
```
backup_prueba13_2024-01-15_14-30-25.zip
```

## 🐛 Troubleshooting

### Error de conexión SSH
- Verificar conectividad: `ping [servidor]`
- Probar SSH manualmente: `ssh user@servidor`
- Verificar sshpass: `which sshpass`

### Error de espacio
- El módulo **NO usa espacio local**
- Verificar espacio en servidor remoto
- Verificar permisos de escritura en directorio destino

### Error de permisos
- Verificar usuario SSH tenga permisos de escritura
- Verificar directorio destino existe o puede crearse

## 📞 Soporte

Para soporte técnico, revisar los logs de Odoo en modo desarrollo o contactar al administrador del sistema.

---
**Desarrollado para Odoo 17.0** | **Versión 1.0.0**