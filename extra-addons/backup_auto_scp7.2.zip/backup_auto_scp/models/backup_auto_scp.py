import os
import logging
from datetime import datetime, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class BackupAutoScp(models.Model):
    _name = 'backup.auto.scp'
    _description = 'Backup Automático SCP'
    _order = 'create_date desc'

    name = fields.Char('Nombre del Backup', required=True, default='Backup Automático')
    database_name = fields.Char('Base de Datos', required=True, default=lambda self: self.env.cr.dbname)
    
    # Configuración del servidor local Odoo
    local_odoo_host = fields.Char('Host Odoo Local', default='localhost', required=True, 
                                  help='IP o dominio donde corre Odoo (localhost, paramo.lago.digital, etc.)')
    local_odoo_port = fields.Char('Puerto Odoo Local', default='8069', required=True,
                                  help='Puerto donde corre Odoo (80, 443, 8069, etc.)')
    master_password = fields.Char('Master Password', default='admin_password', required=True,
                                  help='Master password configurado en odoo.conf')
    
    # Configuración del servidor remoto
    server_host = fields.Char('Servidor SSH', default='5.78.131.185', required=True)
    server_user = fields.Char('Usuario SSH', default='root', required=True)
    server_password = fields.Char('Password SSH', default='xApgsicXgqmX', required=True)
    server_path = fields.Char('Ruta en Servidor', default='/home/a.fecol.digital/odoo17/backups', required=True)
    ssh_key_path = fields.Char('Ruta Clave SSH', default='/root/.ssh/id_rsa_backup', help='Ruta a la clave privada SSH')
    
    # Configuración de frecuencia
    backup_frequency = fields.Selection([
        ('8_hours', 'Cada 8 horas'),
        ('daily', 'Diario'),
        ('manual', 'Solo manual')
    ], default='daily', string='Frecuencia', required=True)
    
    # Modo de backup
    backup_mode = fields.Selection([
        ('remote_scp', 'Enviar a Servidor SSH'),
        ('local_download', 'Descargar en Local'),
        ('both', 'Ambos (SSH + Local)')
    ], default='remote_scp', string='Modo de Backup', required=True)
    
    # Formato de descarga
    download_format = fields.Selection([
        ('zip', 'Completo (ZIP - BD + Filestore)'),
        ('sql', 'Solo SQL Dump (Ligero)')
    ], default='zip', string='Formato de Descarga', required=True)
    
    # Estados y logs
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('active', 'Activo'),
        ('inactive', 'Inactivo')
    ], default='draft', string='Estado')
    
    last_backup_date = fields.Datetime('Último Backup')
    next_backup_date = fields.Datetime('Próximo Backup')
    backup_count = fields.Integer('Total de Backups', default=0)
    
    # Log de resultados
    last_backup_result = fields.Text('Resultado del Último Backup')
    last_backup_size = fields.Char('Tamaño del Último Backup')
    last_backup_file = fields.Char('Último Archivo Creado')
    
    # Variables para control (sin hilos)

    def _get_default_db_name(self):
        return self.env.cr.dbname

    @api.model
    def create(self, vals):
        if not vals.get('database_name'):
            vals['database_name'] = self.env.cr.dbname
        return super().create(vals)

    def action_activate(self):
        """Activar el backup automático"""
        self.ensure_one()
        self.state = 'active'
        self._schedule_next_backup()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': '✅ Backup Activado',
                'message': f'Backup automático activado. Próximo backup: {self.next_backup_date}\\nEl cron ejecutará backups ',
                'type': 'success'
            }
        }

    def action_deactivate(self):
        """Desactivar el backup automático"""
        self.ensure_one()
        self.state = 'inactive'
        self.next_backup_date = False
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': '⏹️ Backup Desactivado',
                'message': 'Backup automático desactivado.',
                'type': 'warning'
            }
        }

    def action_backup_manual(self):
        """Ejecutar backup manual inmediatamente"""
        self.ensure_one()
        try:
            if self.backup_mode in ('local_download', 'both'):
                if not self.local_backup_path:
                    raise Exception("Ruta local no configurada.")
                result = self._execute_backup_local()
            else:
                result = self._execute_backup_scp()
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '🎉 Backup Manual Exitoso',
                    'message': result.get('message', 'Backup completado correctamente'),
                    'type': 'success',
                    'sticky': True
                }
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '❌ Error en Backup Manual',
                    'message': f'Error: {str(e)}',
                    'type': 'danger',
                    'sticky': True
                }
            }

    def action_test_connection(self):
        """Probar la conexión al servidor Odoo local"""
        self.ensure_one()
        try:
            protocol = "https" if self.local_odoo_port == "443" else "http"
            test_url = f"{protocol}://{self.local_odoo_host}:{self.local_odoo_port}/web/database/backup"
            
            import subprocess
            
            # Probar conexión
            test_cmd = [
                'curl',
                '-X', 'POST',
                '-d', f'master_pwd={self.master_password}&name={self.database_name}&backup_format=zip',
                '--max-time', '30',
                '-w', '\n%{http_code}',
                test_url
            ]
            
            _logger.info("🧪 PROBANDO CONEXIÓN: %s", test_url)
            result = subprocess.run(test_cmd, capture_output=True, text=True, timeout=35)
            
            lines = result.stdout.strip().split('\n')
            http_code = lines[-1] if lines else '000'
            
            _logger.info("📊 HTTP Code: %s", http_code)
            _logger.info("📊 Response: %s", result.stdout[-200:] if result.stdout else "")
            
            if http_code == '200':
                msg = f"✅ Conexión exitosa!\nHTTP: {http_code}"
            elif http_code == '403':
                msg = f"❌ Acceso denegado (Error 403)\nVerifica el master_password"
            elif http_code == '404':
                msg = f"❌ URL no encontrada (Error 404)\nVerifica host y puerto"
            else:
                msg = f"⚠️ Respuesta HTTP: {http_code}\nRevisa los logs de Odoo"
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '🧪 Resultado de Prueba',
                    'message': msg,
                    'type': 'success' if http_code == '200' else 'warning',
                    'sticky': True
                }
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '❌ Error en Prueba',
                    'message': f'Error: {str(e)}',
                    'type': 'danger',
                    'sticky': True
                }
            }

    def action_send_to_scp(self):
        """Enviar backup a servidor SSH remotamente"""
        self.ensure_one()
        try:
            result = self._execute_backup_scp()
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '🎉 Backup Enviado a SSH',
                    'message': result.get('message', 'Backup enviado correctamente'),
                    'type': 'success',
                    'sticky': True
                }
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '❌ Error en Envío SSH',
                    'message': f'Error: {str(e)}',
                    'type': 'danger',
                    'sticky': True
                }
            }

    def action_download_backup(self):
        """Generar y descargar el backup según formato seleccionado"""
        self.ensure_one()
        try:
            # Retornar acción para descargar mediante la ruta HTTP
            # El controller se encargará de generar y servir el backup según el formato
            return {
                'type': 'ir.actions.act_url',
                'url': f'/backup/download/{self.id}?format={self.download_format}',
                'target': 'new',  # Abre en nueva pestaña/ventana
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': '❌ Error en Descarga',
                    'message': f'Error: {str(e)}',
                    'type': 'danger',
                    'sticky': True
                }
            }

    def _schedule_next_backup(self):
        """Programar el próximo backup"""
        if self.backup_frequency == '8_hours':
            self.next_backup_date = datetime.now() + timedelta(hours=8)
        elif self.backup_frequency == 'daily':
            self.next_backup_date = datetime.now() + timedelta(days=1)
        else:
            self.next_backup_date = False

# Métodos de hilo eliminados - usando solo cron

    def _execute_backup_scp(self):
        """Ejecutar backup y enviarlo por SCP - Soporte para ZIP o SQL"""
        import subprocess
        _logger.info("🚀 INICIANDO BACKUP SCP")
        
        # Usar ZIP completo para enviar al servidor
        # IMPORTANTE: Sin timestamp - Sobrescribe el anterior para evitar llenar disco
        backup_filename = f"backup_{self.database_name}.zip"
        remote_file_path = f"{self.server_path}/{backup_filename}"
        
        try:
            # Crear directorio temporal local
            temp_backup_path = f"/tmp/{backup_filename}"
            
            _logger.info("📥 CREANDO BACKUP PARA ENVIAR A SERVIDOR SSH")
            _logger.info("🗄️ Base de datos: %s", self.database_name)
            _logger.info("📂 Archivo temporal: %s", temp_backup_path)
            _logger.info("📤 Destino remoto: %s:%s", self.server_host, remote_file_path)
            
            protocol = "https" if self.local_odoo_port == "443" else "http"
            backup_url = f"{protocol}://{self.local_odoo_host}:{self.local_odoo_port}/web/database/backup"
            
            _logger.info("🔗 URL Backup: %s", backup_url)
            _logger.info("📝 Master Password: %s", "*" * len(self.master_password))
            
            # PASO 1: Descargar backup ZIP localmente
            curl_cmd = [
                'curl',
                '-X', 'POST',
                '-d', f'master_pwd={self.master_password}&name={self.database_name}&backup_format=zip',
                '--max-time', '3600',  # 60 minutos para descargar
                '-v',
                backup_url,
                '-o', temp_backup_path
            ]
            
            _logger.info("📥 Descargando backup ZIP...")
            result = subprocess.run(curl_cmd, capture_output=True, text=True, timeout=3610)
            
            _logger.info("📊 Curl return code: %s", result.returncode)
            
            if result.returncode != 0 or not os.path.exists(temp_backup_path):
                raise Exception(f"Error descargando backup (código: {result.returncode})")
            
            file_size = os.path.getsize(temp_backup_path)
            _logger.info("✅ Backup descargado: %s bytes", file_size)
            
            # Validar que sea ZIP válido
            with open(temp_backup_path, 'rb') as f:
                content_start = f.read(100)
            
            if b'<html>' in content_start.lower() or file_size < 1024:
                _logger.error("❌ Error: El archivo descargado es HTML o muy pequeño")
                try:
                    os.remove(temp_backup_path)
                except:
                    pass
                raise Exception("Error descargando backup. Verifica master_password")
            
            if not content_start.startswith(b'PK'):
                _logger.error("❌ Error: No es un archivo ZIP válido")
                _logger.error("❌ Primeros bytes: %s", repr(content_start[:20]))
                try:
                    os.remove(temp_backup_path)
                except:
                    pass
                raise Exception("El archivo descargado no es un ZIP válido")
            
            _logger.info("✅ Validación ZIP correcta - Primeros bytes: %s", repr(content_start[:20]))
            size_mb = file_size / (1024 * 1024)
            size_str = f"{size_mb:.2f} MB"
            _logger.info("📏 Tamaño: %s", size_str)
            
            # PASO 2: Enviar a servidor SSH usando SCP con autenticación por contraseña
            _logger.info("📤 ENVIANDO A SERVIDOR SSH...")
            _logger.info("🖥️ Servidor: %s@%s:%s", self.server_user, self.server_host, self.server_path)
            
            # Crear directorio remoto primero
            ssh_cmd_mkdir = [
                'sshpass',
                '-p', self.server_password,
                'ssh',
                '-o', 'StrictHostKeyChecking=no',
                '-o', 'UserKnownHostsFile=/dev/null',
                f'{self.server_user}@{self.server_host}',
                f'mkdir -p {self.server_path}'
            ]
            
            _logger.info("📁 Creando directorio remoto...")
            mkdir_result = subprocess.run(ssh_cmd_mkdir, capture_output=True, text=True, timeout=30)
            
            if mkdir_result.returncode != 0:
                _logger.warning("⚠️ Aviso al crear directorio: %s", mkdir_result.stderr)
            
            # Enviar archivo con SCP usando contraseña
            scp_cmd = [
                'sshpass',
                '-p', self.server_password,
                'scp',
                '-o', 'StrictHostKeyChecking=no',
                '-o', 'UserKnownHostsFile=/dev/null',
                temp_backup_path,
                f'{self.server_user}@{self.server_host}:{remote_file_path}'
            ]
            
            _logger.info("⏳ Transferiendo archivo (esto puede tardar varios minutos)...")
            _logger.info("📊 Tamaño a transferir: %s", size_str)
            scp_result = subprocess.run(scp_cmd, capture_output=True, text=True, timeout=3600)
            
            if scp_result.returncode == 0:
                _logger.info("✅ Archivo enviado exitosamente")
                
                # Verificar tamaño en servidor
                ssh_cmd_size = [
                    'sshpass',
                    '-p', self.server_password,
                    'ssh',
                    '-o', 'StrictHostKeyChecking=no',
                    '-o', 'UserKnownHostsFile=/dev/null',
                    f'{self.server_user}@{self.server_host}',
                    f'ls -lh {remote_file_path}'
                ]
                
                size_result = subprocess.run(ssh_cmd_size, capture_output=True, text=True, timeout=30)
                
                if size_result.returncode == 0:
                    # Parsear output de ls -lh
                    remote_info = size_result.stdout.strip()
                    _logger.info("📊 Información remota: %s", remote_info)
                    remote_size = remote_info.split()[4] if len(remote_info.split()) > 4 else "Desconocido"
                else:
                    remote_size = "Desconocido"
                
                # Limpiar archivo temporal
                try:
                    os.remove(temp_backup_path)
                    _logger.info("🗑️ Archivo temporal eliminado")
                except Exception as e:
                    _logger.warning("⚠️ Error eliminando temporal: %s", str(e))
                
                # Actualizar registros
                self.write({
                    'last_backup_date': datetime.now(),
                    'backup_count': self.backup_count + 1,
                    'last_backup_result': f'✅ Backup ZIP enviado exitosamente\n🖥️ {self.server_host}\n📂 {remote_file_path}\n📏 Local: {size_str}\n📊 Remoto: {remote_size}',
                    'last_backup_size': remote_size,
                    'last_backup_file': backup_filename
                })
                
                if self.state == 'active':
                    self._schedule_next_backup()
                
                _logger.info("🎉 BACKUP SCP COMPLETADO EXITOSAMENTE")
                _logger.info("📊 Tamaño local: %s", size_str)
                _logger.info("📊 Tamaño remoto: %s", remote_size)
                
                return {
                    'success': True,
                    'message': f'✅ Backup ZIP enviado a {self.server_host}\n📂 {remote_file_path}\n📏 Local: {size_str}\n📊 Remoto: {remote_size}',
                    'file': backup_filename,
                    'size': size_str
                }
            else:
                error_output = scp_result.stderr if scp_result.stderr else scp_result.stdout
                _logger.error("❌ Error en SCP: %s", error_output)
                try:
                    os.remove(temp_backup_path)
                except:
                    pass
                raise Exception(f"Error enviando por SCP:\n{error_output}")
                
        except subprocess.TimeoutExpired as e:
            _logger.error("❌ Timeout en transferencia SCP")
            try:
                if os.path.exists(temp_backup_path):
                    os.remove(temp_backup_path)
            except:
                pass
            self.write({
                'last_backup_result': "❌ Error: Timeout en transferencia SCP (>60 minutos)",
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            raise UserError("Timeout: La transferencia tardó demasiado tiempo (>60 min)")
        except Exception as e:
            error_msg = f"❌ Error en backup SCP: {str(e)}"
            _logger.error(error_msg)
            
            self.write({
                'last_backup_result': error_msg,
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            
            raise UserError(error_msg)

    def _execute_backup_sql(self):
        """Crear solo backup SQL dump (sin filestore) - Más ligero para BBD grandes"""
        import subprocess
        _logger.info("🚀 INICIANDO BACKUP SQL DUMP")
        
        # IMPORTANTE: Sin timestamp - Sobrescribe el anterior para evitar llenar disco
        backup_filename = f"backup_{self.database_name}.sql"
        
        try:
            # Crear un archivo temporal para el backup
            temp_backup_path = f"/tmp/{backup_filename}"
            
            _logger.info("📥 CREANDO BACKUP SQL DUMP (SIN FILESTORE)")
            _logger.info("🗄️ Base de datos: %s", self.database_name)
            _logger.info("📂 Archivo temporal: %s", temp_backup_path)
            
            protocol = "https" if self.local_odoo_port == "443" else "http"
            backup_url = f"{protocol}://{self.local_odoo_host}:{self.local_odoo_port}/web/database/backup"
            
            _logger.info("🔗 URL: %s", backup_url)
            _logger.info("📝 Master Password: %s", "*" * len(self.master_password))
            
            # Usar curl para descargar solo el SQL (formato 'p' = Plain text)
            curl_cmd = [
                'curl',
                '-X', 'POST',
                '-d', f'master_pwd={self.master_password}&name={self.database_name}&backup_format=p',
                '--max-time', '600',  # 10 minutos máximo para SQL
                '-v',
                backup_url,
                '-o', temp_backup_path
            ]
            
            _logger.info("📤 Ejecutando curl para descargar SQL dump...")
            
            # Ejecutar curl
            result = subprocess.run(
                curl_cmd,
                capture_output=True,
                text=True,
                timeout=610
            )
            
            _logger.info("📊 Return code: %s", result.returncode)
            if result.stderr:
                _logger.info("📊 Stderr (últimas 300 chars): %s", result.stderr[-300:])
            
            if result.returncode == 0 and os.path.exists(temp_backup_path):
                file_size = os.path.getsize(temp_backup_path)
                _logger.info("✅ Archivo SQL creado: %s bytes", file_size)
                
                # Verificar que NO sea HTML (error)
                with open(temp_backup_path, 'rb') as f:
                    content_start = f.read(100)
                
                if b'<html>' in content_start.lower() or b'<html ' in content_start.lower() or file_size < 1024:
                    _logger.error("❌ El archivo descargado es HTML (error del servidor)")
                    with open(temp_backup_path, 'r', errors='ignore') as f:
                        error_content = f.read(500)
                    _logger.error("📄 Contenido: %s", error_content)
                    try:
                        os.remove(temp_backup_path)
                    except:
                        pass
                    raise Exception(f"Error del servidor. Master password incorrecto o servidor no disponible")
                
                size_mb = file_size / (1024 * 1024)
                size_str = f"{size_mb:.2f} MB"
                
                # Actualizar registros
                self.write({
                    'last_backup_date': datetime.now(),
                    'backup_count': self.backup_count + 1,
                    'last_backup_result': f'✅ Backup SQL dump generado exitosamente: {backup_filename}',
                    'last_backup_size': size_str,
                    'last_backup_file': backup_filename
                })
                
                # Programar próximo backup si está activo
                if self.state == 'active':
                    self._schedule_next_backup()
                
                _logger.info("🎉 BACKUP SQL DUMP COMPLETADO EXITOSAMENTE")
                _logger.info("📁 Archivo: %s", backup_filename)
                _logger.info("📏 Tamaño: %s", size_str)
                _logger.info("⚡ Solo base de datos (sin filestore)")
                
                return {
                    'success': True,
                    'message': f'✅ Backup SQL dump descargado\n📁 Archivo: {backup_filename}\n📏 Tamaño: {size_str}\n⚡ Solo BD (sin filestore)',
                    'file': backup_filename,
                    'size': size_str
                }
            else:
                error = f"curl error (código: {result.returncode})"
                _logger.error(error)
                raise Exception(error)
                
        except subprocess.TimeoutExpired:
            error_msg = "❌ Error: El backup SQL tardó más de 10 minutos"
            _logger.error(error_msg)
            self.write({
                'last_backup_result': error_msg,
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            raise UserError(error_msg)
        except Exception as e:
            error_msg = f"❌ Error en backup SQL: {str(e)}"
            _logger.error(error_msg)
            
            self.write({
                'last_backup_result': error_msg,
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            
            raise UserError(error_msg)

    def _execute_backup_local(self):
        """Crear backup completo usando la API de Odoo (ZIP con BD + filestore)"""
        import subprocess
        _logger.info("🚀 INICIANDO BACKUP COMPLETO LOCAL")
        
        # IMPORTANTE: Sin timestamp - Sobrescribe el anterior para evitar llenar disco
        backup_filename = f"backup_{self.database_name}.zip"
        
        try:
            # Crear un archivo temporal para el backup
            temp_backup_path = f"/tmp/{backup_filename}"
            
            _logger.info("📥 CREANDO BACKUP COMPLETO (BD + FILESTORE)")
            _logger.info("🗄️ Base de datos: %s", self.database_name)
            _logger.info("📂 Archivo temporal: %s", temp_backup_path)
            
            protocol = "https" if self.local_odoo_port == "443" else "http"
            backup_url = f"{protocol}://{self.local_odoo_host}:{self.local_odoo_port}/web/database/backup"
            
            _logger.info("🔗 URL: %s", backup_url)
            _logger.info("📝 Master Password: %s", "*" * len(self.master_password))
            
            # Usar curl para descargar el backup completo (ZIP)
            curl_cmd = [
                'curl',
                '-X', 'POST',
                '-d', f'master_pwd={self.master_password}&name={self.database_name}&backup_format=zip',
                '--max-time', '7200',  # 120 minutos máximo para BDD grandes (hasta 2GB)
                '-v',
                backup_url,
                '-o', temp_backup_path
            ]
            
            _logger.info("📤 Ejecutando curl para descargar backup...")
            
            # Ejecutar curl
            result = subprocess.run(
                curl_cmd,
                capture_output=True,
                text=True,
                timeout=7210  # 120+ minutos para completar
            )
            
            _logger.info("📊 Return code: %s", result.returncode)
            if result.stderr:
                _logger.info("📊 Stderr (últimas 300 chars): %s", result.stderr[-300:])
            
            if result.returncode == 0 and os.path.exists(temp_backup_path):
                file_size = os.path.getsize(temp_backup_path)
                _logger.info("✅ Archivo creado: %s bytes", file_size)
                
                # Verificar que NO sea HTML (error)
                with open(temp_backup_path, 'rb') as f:
                    content_start = f.read(100)
                
                if b'<html>' in content_start.lower() or b'<html ' in content_start.lower() or file_size < 1024:
                    _logger.error("❌ El archivo descargado es HTML (error del servidor)")
                    with open(temp_backup_path, 'r', errors='ignore') as f:
                        error_content = f.read(500)
                    _logger.error("📄 Contenido: %s", error_content)
                    try:
                        os.remove(temp_backup_path)
                    except:
                        pass
                    raise Exception(f"Error del servidor. Master password incorrecto o servidor no disponible")
                
                # Verificar que sea un ZIP válido
                if not (content_start.startswith(b'PK') or content_start.startswith(b'\x50\x4b')):
                    _logger.error("❌ El archivo no es un ZIP válido")
                    try:
                        os.remove(temp_backup_path)
                    except:
                        pass
                    raise Exception("Archivo descargado no es un ZIP válido. Verifica la conexión.")
                
                size_mb = file_size / (1024 * 1024)
                size_str = f"{size_mb:.2f} MB"
                
                # Actualizar registros
                self.write({
                    'last_backup_date': datetime.now(),
                    'backup_count': self.backup_count + 1,
                    'last_backup_result': f'✅ Backup completo generado exitosamente: {backup_filename}',
                    'last_backup_size': size_str,
                    'last_backup_file': backup_filename
                })
                
                # Programar próximo backup si está activo
                if self.state == 'active':
                    self._schedule_next_backup()
                
                _logger.info("🎉 BACKUP LOCAL COMPLETADO EXITOSAMENTE")
                _logger.info("📁 Archivo: %s", backup_filename)
                _logger.info("📏 Tamaño: %s", size_str)
                _logger.info("💾 BD + Filestore incluidos")
                
                return {
                    'success': True,
                    'message': f'✅ Backup completo descargado localmente\n📁 Archivo: {backup_filename}\n📏 Tamaño: {size_str}\n💾 Incluye: BD + Filestore',
                    'file': backup_filename,
                    'size': size_str
                }
            else:
                error = f"curl error (código: {result.returncode})"
                _logger.error(error)
                raise Exception(error)
                
        except subprocess.TimeoutExpired:
            error_msg = "❌ Error: El backup tardó más de 120 minutos (2 horas)"
            _logger.error(error_msg)
            self.write({
                'last_backup_result': error_msg,
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            raise UserError(error_msg)
        except Exception as e:
            error_msg = f"❌ Error en backup local: {str(e)}"
            _logger.error(error_msg)
            
            self.write({
                'last_backup_result': error_msg,
                'last_backup_size': 'Error',
                'last_backup_file': 'Error'
            })
            
            raise UserError(error_msg)

    @api.model
    def cron_auto_backup(self):
        """Método para el cron automático - USA CONFIGURACIÓN DEL USUARIO"""
        import time
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        _logger.info("=" * 80)
        _logger.info("🕐 [%s] EJECUTANDO CRON DE BACKUP AUTOMÁTICO", timestamp)
        _logger.info("=" * 80)
        
        # Buscar configuración activa del usuario
        active_backup = self.search([('state', '=', 'active')], limit=1)
        if not active_backup:
            _logger.warning("⚠️ No hay configuración de backup activa")
            _logger.info("=" * 80)
            return
        
        _logger.info("✅ Configuración encontrada: %s", active_backup.name)
        _logger.info("📊 BD: %s | Modo: %s | Frecuencia: %s", 
                     active_backup.database_name, 
                     active_backup.backup_mode,
                     active_backup.backup_frequency)
        
        try:
            start_time = time.time()
            
            # Ejecutar según el modo configurado
            if active_backup.backup_mode == 'remote_scp':
                _logger.info("🚀 Ejecutando backup por SSH...")
                active_backup._execute_backup_scp()
            elif active_backup.backup_mode == 'local_download':
                _logger.info("💾 Ejecutando descarga local...")
                active_backup._execute_backup_local()
            else:  # both
                _logger.info("🔄 Ejecutando ambos (SSH + Local)...")
                active_backup._execute_backup_scp()
                active_backup._execute_backup_local()
            
            elapsed = time.time() - start_time
            _logger.info("⏱️ Tiempo de ejecución: %.2f segundos", elapsed)
                
        except Exception as e:
            _logger.error("❌ Error en backup cron: %s", str(e))
            _logger.error("❌ Traceback: ", exc_info=True)
        
        _logger.info("🏁 CRON DE BACKUP AUTOMÁTICO TERMINADO")
        _logger.info("=" * 80)