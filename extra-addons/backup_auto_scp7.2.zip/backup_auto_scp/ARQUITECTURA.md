# 🏗️ ARQUITECTURA DEL MÓDULO

## 📐 Diagrama de Flujo General

```
┌─────────────────────────────────────────────────────────────┐
│                      ODOO 17 LOCAL                          │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Interfaz Web (Backup Automático)                    │   │
│  │  - Botones: Probar, Backup, Descargar, Enviar SSH   │   │
│  └────────────┬─────────────────────────────────────────┘   │
│               │                                              │
└───────────────┼──────────────────────────────────────────────┘
                │
     ┌──────────┴──────────┐
     │                     │
     ▼                     ▼
  CURL HTTP         SUBPROCESS
  :8069/backup      SSH/SCP CMD
     │                     │
     │      ┌──────────────┴──────────────┐
     │      │                             │
     ▼      ▼                             ▼
  ZIP FILE  SSHPASS              REMOTE SSH SERVER
  (LOCAL)   (Auth)               157.180.32.7
            │                         │
            │      ┌──────────────────┘
            │      │
            └──────┴─────► /tmp/backup.zip
                          │
                   ┌──────┴──────────┐
                   │                 │
                   ▼                 ▼
              VALIDACIÓN         TRANSFERENCIA
              (Magic bytes)      (SCP binary)
                   │                 │
                   └────────┬────────┘
                            ▼
                   /home/backup_user/backups/
                   backup_admin_*.zip
```

---

## 🔄 Flujo de Backup Local

```
Usuario hace clic en "⬇️ Descargar"
        │
        ▼
action_download_backup()
        │
        ├─→ Genera URL temporal
        │
        └─→ Retorna descarga HTTP
                │
                ▼
        Navegador descarga ZIP
        
Tiempo: ~5-10 minutos (según BD)
```

---

## 🚀 Flujo de Backup SSH/SCP

```
Usuario hace clic en "📤 Enviar a SSH"
        │
        ▼
action_send_to_scp()
        │
        ├─→ Validar configuración SSH
        │
        └─→ _execute_backup_scp()
            │
            ├─→ PASO 1: Descargar ZIP local
            │   │
            │   ├─→ Construir URL Odoo
            │   │   http://host:port/web/database/backup
            │   │
            │   ├─→ Ejecutar CURL
            │   │   subprocess.run(['curl', '-X', 'POST', ...])
            │   │
            │   └─→ Guardar en /tmp/backup_*.zip
            │
            ├─→ PASO 2: Validar integridad
            │   │
            │   ├─→ Leer primeros 100 bytes
            │   │
            │   ├─→ Verificar ZIP magic bytes b'PK'
            │   │
            │   └─→ Rechazar si es HTML/corrupto
            │
            ├─→ PASO 3: Crear directorio remoto
            │   │
            │   ├─→ Ejecutar SSHPASS
            │   │   ['sshpass', '-p', password,
            │   │    'ssh', 'mkdir -p /ruta']
            │   │
            │   └─→ Ignorar error si ya existe
            │
            ├─→ PASO 4: Transferir archivo
            │   │
            │   ├─→ Ejecutar SCP con SSHPASS
            │   │   ['sshpass', '-p', password,
            │   │    'scp', temp_file,
            │   │    'user@host:remote_path']
            │   │
            │   ├─→ Esperar con timeout 3600s
            │   │
            │   └─→ Manejar errores de transferencia
            │
            ├─→ PASO 5: Verificar en servidor
            │   │
            │   ├─→ Ejecutar ls -lh remoto
            │   │
            │   └─→ Confirmar tamaño = tamaño local
            │
            ├─→ PASO 6: Limpiar temporal
            │   │
            │   └─→ os.remove(/tmp/backup_*.zip)
            │
            ├─→ PASO 7: Actualizar registro
            │   │
            │   ├─→ last_backup_date = now
            │   ├─→ backup_count += 1
            │   ├─→ last_backup_result = "✅ Exitoso..."
            │   ├─→ last_backup_size = remote_size
            │   └─→ last_backup_file = filename
            │
            └─→ RETORNAR resultado

Tiempo: 45-120 minutos (según tamaño BD)
```

---

## 📁 Estructura de Archivos del Módulo

```
backup_auto_scp/
│
├── __manifest__.py                 # Metadatos del módulo
│   ├── name
│   ├── version
│   ├── category
│   ├── depends
│   ├── data
│   └── installable
│
├── __init__.py                     # Importa models y controllers
│
├── models/
│   ├── __init__.py                 # from . import backup_auto_scp
│   │
│   └── backup_auto_scp.py          # LÓGICA PRINCIPAL (700+ líneas)
│       ├── BackupAutoScp (class)
│       │   ├── _name = "backup.auto.scp"
│       │   ├── _description = "Backup Automático..."
│       │   │
│       │   ├── CAMPOS:
│       │   │   ├── database_name          (Char)
│       │   │   ├── frequency              (Selection)
│       │   │   ├── backup_mode            (Selection)
│       │   │   ├── download_format        (Selection)
│       │   │   ├── local_odoo_host        (Char)
│       │   │   ├── local_odoo_port        (Integer)
│       │   │   ├── master_password        (Password)
│       │   │   ├── server_host            (Char)
│       │   │   ├── server_user            (Char)
│       │   │   ├── server_password        (Password)
│       │   │   ├── server_path            (Char)
│       │   │   ├── ssh_key_path           (Char)
│       │   │   ├── last_backup_date       (Datetime)
│       │   │   ├── backup_count           (Integer)
│       │   │   ├── last_backup_result     (Text)
│       │   │   ├── last_backup_size       (Char)
│       │   │   └── last_backup_file       (Char)
│       │   │
│       │   ├── MÉTODOS PRIVADOS:
│       │   │   ├── _execute_backup_local()     → Descargar ZIP
│       │   │   ├── _execute_backup_scp()       → Enviar SSH
│       │   │   ├── _execute_backup_sql()       → SQL Dump
│       │   │   └── _schedule_next_backup()     → Cron
│       │   │
│       │   └── MÉTODOS PÚBLICOS (Botones):
│       │       ├── action_test_connection()    → Test SSH
│       │       ├── action_backup_manual()      → Backup manual
│       │       ├── action_download_backup()    → Descargar
│       │       ├── action_send_to_scp()        → Enviar SSH
│       │       ├── action_activate()           → Activar cron
│       │       └── action_deactivate()         → Desactivar cron
│
├── controllers/
│   ├── __init__.py                 # from . import backup_controller
│   │
│   └── backup_controller.py        # ENDPOINT HTTP
│       ├── BackupController (class)
│       │   └── /backup/download/<id>
│       │       ├── Validar backup_id
│       │       ├── Generar URL descarga
│       │       ├── Descargar archivo
│       │       ├── Stream al navegador
│       │       └── Limpiar temporal
│
├── views/
│   ├── backup_auto_scp_views.xml   # INTERFAZ
│   │   ├── Form view
│   │   │   ├── Database Config (group)
│   │   │   ├── Odoo Local Config (group)
│   │   │   ├── SSH Config (group - conditional)
│   │   │   ├── Statistics (group)
│   │   │   └── Last Backup Result (group)
│   │   │
│   │   ├── Tree view (lista)
│   │   │
│   │   ├── Kanban view (visual)
│   │   │
│   │   ├── Buttons:
│   │   │   ├── Test Connection
│   │   │   ├── Backup Manual
│   │   │   ├── Download
│   │   │   ├── Send to SSH
│   │   │   ├── Activate
│   │   │   └── Deactivate
│   │   │
│   │   └── Search view
│   │
│   └── menu.xml                    # MENÚ
│       ├── backup_auto_scp_menu
│       └── backup_auto_scp_action
│
├── security/
│   └── ir.model.access.csv         # PERMISOS
│       ├── base.group_user (read, create, write, unlink)
│       └── base.group_system (full access)
│
├── data/
│   └── cron.xml                    # SCHEDULED JOBS (opcional)
│
└── README.md                       # DOCUMENTACIÓN
```

---

## 🔌 Puntos de Integración

### 1. Odoo ORM
```python
self.env['backup.auto.scp'].search([])
self.write({'last_backup_date': datetime.now()})
```

### 2. Scheduler (Cron)
```python
@api.model
def _schedule_next_backup():
    # Crear ir.cron automáticamente
    # Ejecutar según frecuencia
```

### 3. HTTP Routing
```python
@http.route('/backup/download/<int:backup_id>', 
            type='http', auth='user')
def download_backup(self, backup_id):
    # Endpoint para descargar
```

### 4. Sistema de Archivos
```python
# Lectura:
with open('/tmp/backup.zip', 'rb') as f:
    content = f.read()

# Escritura:
os.makedirs('/tmp', exist_ok=True)
```

### 5. Subprocess (Sistema Operativo)
```python
# Ejecutar comandos externos
subprocess.run(['curl', ...], capture_output=True)
subprocess.run(['sshpass', '-p', pwd, 'scp', ...])
```

---

## 🔐 Seguridad

### Validaciones
1. ✅ Contraseña maestra de Odoo
2. ✅ Validación de ZIP (magic bytes b'PK')
3. ✅ Autenticación SSH (contraseña o clave)
4. ✅ Permiso de usuario (ir.model.access.csv)

### Encriptación
- ✅ Campo `master_password` → Password type (encriptado)
- ✅ Campo `server_password` → Password type (encriptado)
- ✅ SSH connection → Already encrypted

### Logs
- ✅ Todos los eventos registrados
- ✅ Contraseñas ocultadas en logs (****)
- ✅ Errores detallados para debugging

---

## 📊 Base de Datos

### Tabla: backup_auto_scp

```sql
CREATE TABLE backup_auto_scp (
    id SERIAL PRIMARY KEY,
    database_name VARCHAR(255) NOT NULL,
    frequency VARCHAR(50),          -- 8_hours, daily, manual
    backup_mode VARCHAR(50),         -- remote_scp, local_download, both
    download_format VARCHAR(50),     -- zip, sql
    local_odoo_host VARCHAR(255),
    local_odoo_port INTEGER,
    master_password TEXT,            -- Encriptado
    server_host VARCHAR(255),
    server_user VARCHAR(255),
    server_password TEXT,            -- Encriptado
    server_path VARCHAR(500),
    ssh_key_path VARCHAR(500),
    last_backup_date TIMESTAMP,
    backup_count INTEGER DEFAULT 0,
    last_backup_result TEXT,
    last_backup_size VARCHAR(50),
    last_backup_file VARCHAR(255),
    state VARCHAR(50),               -- draft, active, inactive
    create_date TIMESTAMP,
    write_date TIMESTAMP,
    create_uid INTEGER,
    write_uid INTEGER,
    
    FOREIGN KEY (create_uid) REFERENCES res_users(id),
    FOREIGN KEY (write_uid) REFERENCES res_users(id)
);
```

---

## ⏰ Scheduler (Cron)

### Registros automáticos

```xml
<!-- Si frecuencia = "8_hours" -->
<record model="ir.cron" id="cron_backup_8h">
    <field name="name">Backup cada 8 horas</field>
    <field name="model_id" ref="model_backup_auto_scp"/>
    <field name="state">code</field>
    <field name="code">
        env['backup.auto.scp'].search([('frequency', '=', '8_hours')]).action_backup_manual()
    </field>
    <field name="interval_number">8</field>
    <field name="interval_type">hours</field>
    <field name="active" eval="False"/>
</record>
```

---

## 🌐 API REST (Opcional Future)

```python
# Posible extensión futura
@http.route('/api/backup', type='json', auth='bearer')
def backup_api():
    return {
        'status': 'success',
        'backup': {
            'id': 1,
            'database': 'admin',
            'size': '500MB',
            'date': '2025-12-23 10:00:00'
        }
    }
```

---

## 🚦 Estados del Modelo

```
┌─────────┐
│ DRAFT   │  Configuración nueva (sin activar)
└────┬────┘
     │
     ▼
┌─────────────┐
│ ACTIVE      │  Backups automáticos en ejecución
└────┬────────┘
     │
     ▼
┌──────────────┐
│ INACTIVE     │  Parado (puede volver a activar)
└──────────────┘
```

---

## 📈 Escalabilidad

### Versión 1.0 (Actual)
- ✅ 1 servidor local
- ✅ 1 servidor remoto
- ✅ Multi-base de datos (múltiples configs)
- ✅ Hasta 2GB BD

### Futuras mejoras
- 🔲 Multi-destino SSH (múltiples servidores)
- 🔲 Cloud storage (S3, Azure, GCP)
- 🔲 Compresión configurable
- 🔲 Incrementales
- 🔲 Replicación
- 🔲 API REST
- 🔲 Webhooks

---

## 🧪 Testing

### Casos de prueba

```python
# test_backup_local()
# test_backup_scp()
# test_backup_sql()
# test_ssh_connection()
# test_zip_validation()
# test_cron_scheduling()
```

---

**Última actualización:** 23 Diciembre 2025

**Versión:** 1.0 Stable
