# -*- coding: utf-8 -*-
import os
import logging
import subprocess
from odoo import http
from odoo.http import request, Response

_logger = logging.getLogger(__name__)


class BackupDownloadController(http.Controller):
    
    @http.route('/backup/download/<int:backup_id>', type='http', auth='user', csrf=False)
    def download_backup(self, backup_id, format='zip', **kwargs):
        """Descargar el backup en formato ZIP o SQL según parámetro"""
        try:
            backup = request.env['backup.auto.scp'].sudo().browse(backup_id)
            
            if not backup:
                return Response("Backup no encontrado", status=404)
            
            # Usar el formato del parámetro o del modelo
            backup_format = format or backup.download_format
            
            # Determinar extensión y parámetros según formato
            if backup_format == 'sql':
                extension = '.sql'
                curl_format = 'p'  # Plain text SQL
                timeout_secs = 1800  # 30 minutos para SQL
                content_type = 'application/sql'
            else:  # zip (default)
                extension = '.zip'
                curl_format = 'zip'
                timeout_secs = 7200  # 120 minutos para ZIP (hasta 2GB)
                content_type = 'application/zip'
            
            # Crear el backup con timestamp
            from datetime import datetime
            backup_filename = f"backup_{backup.database_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{extension}"
            temp_backup_path = f"/tmp/{backup_filename}"
            
            protocol = "https" if backup.local_odoo_port == "443" else "http"
            backup_url = f"{protocol}://{backup.local_odoo_host}:{backup.local_odoo_port}/web/database/backup"
            
            _logger.info("📥 PREPARANDO DESCARGA DE BACKUP: %s (%s)", backup_filename, backup_format.upper())
            _logger.info("🔗 URL: %s", backup_url)
            _logger.info("📝 Master Password: %s", "*" * len(backup.master_password))
            _logger.info("🗄️ Database: %s", backup.database_name)
            _logger.info("⏱️ Timeout: %d segundos", timeout_secs)
            
            # Crear el backup usando curl con formato especificado
            download_cmd = [
                'curl',
                '-X', 'POST',
                '-d', f'master_pwd={backup.master_password}&name={backup.database_name}&backup_format={curl_format}',
                '--max-time', str(timeout_secs),
                '-v',
                backup_url,
                '-o', temp_backup_path
            ]
            
            _logger.info("📤 Ejecutando comando curl con formato: %s", curl_format)
            
            # Ejecutar usando subprocess para mejor control
            result = subprocess.run(download_cmd, capture_output=True, text=True, timeout=timeout_secs+10)
            
            _logger.info("📊 Stdout: %s", result.stdout[-500:] if result.stdout else "")
            _logger.info("📊 Stderr: %s", result.stderr[-500:] if result.stderr else "")
            _logger.info("📊 Return code: %s", result.returncode)
            
            if result.returncode == 0 and os.path.exists(temp_backup_path):
                file_size = os.path.getsize(temp_backup_path)
                _logger.info("✅ Archivo creado: %s bytes", file_size)
                
                # Verificar que no sea HTML o error del servidor
                with open(temp_backup_path, 'rb') as f:
                    content_start = f.read(200)
                
                # Detectar si es HTML (error del servidor)
                if b'<html>' in content_start.lower() or b'<!doctype' in content_start.lower() or b'<html ' in content_start.lower() or file_size < 1024:
                    _logger.error("❌ El archivo descargado es HTML (error del servidor)")
                    with open(temp_backup_path, 'r', errors='ignore') as f:
                        error_content = f.read(500)
                    _logger.error("📄 Contenido: %s", error_content)
                    try:
                        os.remove(temp_backup_path)
                    except:
                        pass
                    return Response("Error: El servidor retornó HTML. Verifica master_password, host y puerto.", status=500)
                
                # Validar según formato
                if backup_format == 'zip':
                    # Verificar que sea un ZIP válido (debe empezar con bytes PK)
                    if not content_start.startswith(b'PK\x03\x04'):
                        _logger.error("❌ El archivo no es un ZIP válido")
                        _logger.error("❌ Primeros bytes: %s", repr(content_start[:10]))
                        try:
                            os.remove(temp_backup_path)
                        except:
                            pass
                        raise Exception("Archivo descargado no es un ZIP válido. Verifica la conexión a Odoo.")
                
                # Leer el archivo completo
                with open(temp_backup_path, 'rb') as f:
                    file_content = f.read()
                
                # Limpiar archivo temporal
                try:
                    os.remove(temp_backup_path)
                except:
                    pass
                
                _logger.info("🎉 DESCARGA COMPLETADA: %s (%.2f MB)", backup_filename, file_size / (1024*1024))
                if backup_format == 'zip':
                    _logger.info("💾 Archivo ZIP válido listo para descargar (BD + Filestore)")
                else:
                    _logger.info("💾 Archivo SQL válido listo para descargar (Solo BD)")
                
                # Retornar el archivo para descargar con Content-Type apropiado
                headers = [
                    ('Content-Type', content_type),
                    ('Content-Disposition', f'attachment; filename="{backup_filename}"'),
                    ('Content-Length', str(len(file_content)))
                ]
                return Response(file_content, headers=headers)
            else:
                _logger.error("❌ Error en curl (código: %s)", result.returncode)
                try:
                    os.remove(temp_backup_path)
                except:
                    pass
                return Response(f"Error descargando backup (código: {result.returncode})", status=500)
                
        except subprocess.TimeoutExpired:
            _logger.error("❌ Timeout: Backup tardó más de 120 minutos (2 horas)")
            return Response("Timeout: El backup tardó demasiado tiempo (más de 2 horas). Si es >2GB, considera usar SQL Dump.", status=504)
        except Exception as e:
            _logger.error("❌ Error en descarga: %s", str(e))
            return Response(f"Error: {str(e)}", status=500)
    
    @http.route('/backup/status/<int:backup_id>', type='json', auth='user')
    def get_backup_status(self, backup_id):
        """Obtener el estado del último backup"""
        try:
            backup = request.env['backup.auto.scp'].sudo().browse(backup_id)
            
            if not backup:
                return {'error': 'Backup no encontrado', 'status': 'error'}
            
            return {
                'status': 'success',
                'last_backup_file': backup.last_backup_file,
                'last_backup_date': str(backup.last_backup_date) if backup.last_backup_date else None,
                'last_backup_size': backup.last_backup_size,
                'last_backup_result': backup.last_backup_result,
            }
        except Exception as e:
            return {'error': str(e), 'status': 'error'}
