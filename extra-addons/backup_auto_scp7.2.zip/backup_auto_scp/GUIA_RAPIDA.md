# 🚀 GUÍA RÁPIDA - Backup Automático SSH/SCP

## 📋 Checklist de Instalación

### 1️⃣ Instalar Herramientas (Servidor Local)

```bash
sudo apt-get install curl sshpass -y
# Verificar
which curl sshpass ssh
```

### 2️⃣ Crear Usuario en Servidor Remoto

```bash
# SSH al servidor remoto
ssh user@157.180.32.7

# Como root:
sudo useradd -m backup_user
sudo mkdir -p /home/backup_user/backups
sudo chown backup_user:backup_user /home/backup_user/backups
sudo passwd backup_user
```

### 3️⃣ Instalar Módulo en Odoo

- `Administración` → `Módulos`
- Buscar `backup_auto_scp`
- `Instalar`

### 4️⃣ Probar Conectividad

```bash
# Test 1: Odoo local
curl -X POST -d "master_pwd=admin_password&name=admin&backup_format=zip" \
  "http://localhost:8069/web/database/backup" -o /tmp/test.zip

# Test 2: SSH
sshpass -p "contraseña" ssh backup_user@157.180.32.7 "ls /home/backup_user/backups"
```

### 5️⃣ Configurar en Odoo

| Campo | Valor |
|-------|-------|
| **Host Odoo Local** | localhost (o IP remota) |
| **Puerto Odoo Local** | 8069 |
| **Master Password** | admin_password |
| **Servidor SSH** | 157.180.32.7 |
| **Usuario SSH** | backup_user |
| **Contraseña SSH** | tu_contraseña |
| **Ruta en Servidor** | /home/backup_user/backups |

### 6️⃣ Test en Odoo

- Botón: **🔗 Probar Conexión**
- Debe mostrar: ✅ Conexión exitosa

---

## 🎯 Uso Rápido

### Descargar ZIP local
→ Botón **⬇️ Descargar Backup**

### Enviar a SSH
→ Botón **📤 Enviar a SSH**

### Activar Automático
→ Frecuencia: `Diario` / `8 Horas`
→ Botón **▶️ Activar**

### Verificar en servidor
```bash
ssh backup_user@157.180.32.7 "ls -lh /home/backup_user/backups/"
unzip -t /home/backup_user/backups/backup_*.zip
```

---

## ⚠️ Problemas Comunes

| Problema | Solución |
|----------|----------|
| "Access Denied" | Verificar `admin_passwd` en odoo.conf |
| "Connection refused" SSH | Verificar firewall: `sudo ufw allow 22/tcp` |
| "Permission denied" | `sudo chown backup_user:backup_user /home/backup_user/backups` |
| "proxy_mode" bloquea | Cambiar a `proxy_mode = False` en odoo.conf remoto |

---

## 📊 Información Rápida

- **Tamaño máximo**: 2GB+ (timeout 120 minutos)
- **Velocidad típica**: 800MB en 45 minutos
- **Compresión**: ~60% (600MB → 360MB)
- **Espacio needed**: 3x tamaño de la BD
- **Frecuencia**: Manual, cada 8 horas, o diario

---

**Última actualización:** 23 Diciembre 2025
