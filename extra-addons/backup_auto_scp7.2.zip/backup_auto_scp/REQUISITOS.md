# ✅ REQUISITOS DEL MÓDULO - Backup Automático SSH/SCP

## 📦 Software Requerido

### En el Servidor Local (donde instalarás el módulo)

#### Obligatorio:
- ✅ **Odoo 17.0** o superior
- ✅ **Python 3.10+** (incluido en Odoo 17)
- ✅ **curl** - Herramienta para descargar backups
  ```bash
  sudo apt-get install curl
  which curl  # /usr/bin/curl
  ```
- ✅ **sshpass** - Autenticación SSH por contraseña
  ```bash
  sudo apt-get install sshpass
  which sshpass  # /usr/bin/sshpass
  ```
- ✅ **OpenSSH Client** - Cliente SSH
  ```bash
  which ssh  # /usr/bin/ssh
  ```

#### Opcional pero recomendado:
- 📦 **postgresql-client** - Para backups SQL directo
  ```bash
  sudo apt-get install postgresql-client
  ```

### En el Servidor Remoto (destino SSH)

#### Obligatorio:
- ✅ **OpenSSH Server** - Servidor SSH
  ```bash
  sudo systemctl status ssh
  # Si no está: sudo apt-get install openssh-server
  ```
- ✅ **Espacio en Disco** - Mínimo 3x el tamaño de la BD
  ```bash
  # Ejemplo: BD 800MB → necesita 2.4GB
  df -h /home  # Verificar
  ```
- ✅ **Usuario SSH** - Con acceso a directorio de backups
  ```bash
  sudo useradd -m backup_user
  sudo mkdir -p /home/backup_user/backups
  sudo chown backup_user:backup_user /home/backup_user/backups
  ```

---

## 🔧 Versiones Compatibles

| Componente | Versión | Requerida | Probada |
|-----------|---------|-----------|---------|
| **Odoo** | 17.0+ | ✅ | 17.0 |
| **Python** | 3.10+ | ✅ | 3.11.14 |
| **PostgreSQL** | 12+ | ✅ | 15 |
| **curl** | 7.0+ | ✅ | 7.81.0 |
| **sshpass** | 1.0+ | ✅ | 1.09 |
| **OpenSSH** | 8.0+ | ✅ | 8.x |

---

## 💾 Espacio en Disco Requerido

### Servidor Local

| Elemento | Espacio | Descripción |
|----------|---------|-------------|
| **Módulo backup_auto_scp** | ~500KB | Archivos Python |
| **Temporal `/tmp`** | 1x BD | Para descarga temporal |
| **Logs** | ~10MB/mes | Histórico de ejecuciones |
| **Total** | ~1x BD + 1GB | Mínimo recomendado |

**Ejemplo con BD de 800MB:**
- Módulo: 0.5MB
- Temporal: 800MB
- Logs: 10MB
- **Total: ~810MB**

### Servidor Remoto

| Elemento | Espacio | Descripción |
|----------|---------|-------------|
| **Backups (comprimidos)** | ~0.6x BD | 60% de compresión típica |
| **Espacio libre** | 1x BD | Para nuevos backups |
| **Total recomendado** | 3x BD | Rotación de 3 backups |

**Ejemplo con BD de 800MB:**
- Cada backup: ~480MB (comprimido)
- 3 backups: ~1.4GB
- **Total: ~1.4GB mínimo**

---

## 🔐 Permisos Requeridos

### Servidor Local

```bash
# Usuario que ejecuta Odoo
ps aux | grep odoo-bin
# Típicamente: odoo, root, www-data, etc.

# Permisos necesarios:
# - Lectura/escritura en /tmp
# - Acceso a curl y sshpass
# - Acceso a SSH keys (si usas)
```

### Servidor Remoto

```bash
# Usuario backup_user necesita:
# - Escritura en /home/backup_user/backups
# - Lectura/escritura en directorio personal
# - Acceso SSH habilitado

# Verificar:
ssh backup_user@157.180.32.7 'mkdir -p /home/backup_user/backups && ls -la'
```

---

## 🌐 Conectividad Requerida

### Red

- ✅ **Puerto 8069** - Abierto entre servidor local y Odoo (puede ser remoto)
- ✅ **Puerto 22** - SSH abierto entre servidor local y servidor remoto
- ✅ **Conexión a Internet** - Para descargas iniciales

### Firewall

```bash
# En servidor remoto
sudo ufw allow 22/tcp   # SSH
sudo ufw allow 8069/tcp # Odoo (si es remoto)

# En servidor local
# Permitir salida hacia puerto 22 y 8069
```

### DNS/Resolución

- ✅ Resolución de nombres o IPs directas

---

## 🗄️ Base de Datos Requerimientos

### PostgreSQL

- ✅ **Versión**: 12+
- ✅ **Encoding**: UTF-8
- ✅ **Conexión**: Debe estar accesible por curl al endpoint de backup
- ✅ **Usuario**: Debe tener permisos de backup

```bash
# Verificar
sudo -u postgres psql -l | grep admin
```

### Tamaño Soportado

| Tamaño BD | Tiempo | Recursos | ✅ Soportado |
|-----------|--------|----------|-------------|
| 1-100 MB | 5-10 min | Mínimo | ✅ Excelente |
| 100-500 MB | 15-30 min | Bajo | ✅ Muy bueno |
| 500 MB - 1 GB | 30-60 min | Moderado | ✅ Bueno |
| 1-2 GB | 60-120 min | Alto | ✅ Soportado |
| 2+ GB | 120+ min | Muy alto | ⚠️ Posible* |

*Requiere timeout personalizado (editar código)

---

## 🚀 Configuración del Sistema

### En el Servidor Local

**odoo.conf debe incluir:**

```ini
[options]
# Obligatorio
admin_passwd = tu_contraseña_maestro

# Para backup remoto
proxy_mode = False  # (si es Odoo local)
# O modificar acceso SSH si proxy_mode = True

# Recomendado
workers = 0  # O 1 para máquinas pequeñas
```

### En el Servidor Remoto

**odoo.conf debe incluir (si es Odoo 17):**

```ini
[options]
admin_passwd = C+UQYz9OKihLWPSZ  # Tu contraseña
proxy_mode = False  # Importante para permite backups remotos
```

---

## 📝 Instalación Paso a Paso

### 1. Verificar Software

```bash
# En servidor local
curl --version
sshpass -V
ssh -V
python3 --version

# En servidor remoto
ssh user@servidor "ssh -V"
ssh user@servidor "which scp"
```

### 2. Preparar Servidor Remoto

```bash
ssh backup_user@157.180.32.7 << 'EOF'
mkdir -p /home/backup_user/backups
chmod 700 /home/backup_user/backups
ls -la /home/backup_user/
EOF
```

### 3. Copiar Módulo

```bash
# El módulo ya debe estar en:
# /home/alejandroxdc/Documentos/odoo/17/odoo17prueba2/odoo17fecol/backup_auto_scp/

# Verificar que esté en addons_path de odoo.conf
grep addons_path odoo.conf
```

### 4. Reiniciar Odoo

```bash
pkill -f odoo-bin
./odoo-bin -c odoo.conf
```

### 5. Instalar Módulo

- Administración → Módulos
- Buscar `backup_auto_scp`
- Instalar

---

## 🧪 Verificación de Requisitos

### Script de verificación

```bash
#!/bin/bash
echo "=== VERIFICANDO REQUISITOS ==="

# Local
echo "✓ Curl:"
which curl

echo "✓ SSH:"
which ssh

echo "✓ SSHPass:"
which sshpass

echo "✓ Python:"
python3 --version

# Remoto
echo "✓ Conectividad remota:"
sshpass -p "password" ssh -o ConnectTimeout=5 user@157.180.32.7 "echo OK"

echo "=== FIN VERIFICACIÓN ==="
```

---

## 🆘 Troubleshooting Requisitos

| Error | Causa | Solución |
|-------|-------|----------|
| `curl: command not found` | curl no instalado | `sudo apt-get install curl` |
| `sshpass: command not found` | sshpass no instalado | `sudo apt-get install sshpass` |
| `ssh: command not found` | OpenSSH no instalado | `sudo apt-get install openssh-client` |
| `Permission denied` | Usuario sin permisos | Crear usuario backup_user con permisos |
| `Connection refused` | SSH no corre | `sudo systemctl restart ssh` |
| `No space left on device` | Sin espacio | Aumentar partición o limpiar |

---

## 📋 Checklist Final

Antes de usar el módulo, verifica:

- [ ] ✅ `curl` instalado y funcionando
- [ ] ✅ `sshpass` instalado y funcionando
- [ ] ✅ `ssh` accesible
- [ ] ✅ Usuario de backup creado en servidor remoto
- [ ] ✅ Directorio `/home/backup_user/backups` con permisos
- [ ] ✅ Conectividad SSH al servidor remoto (puerto 22 abierto)
- [ ] ✅ Conectividad a Odoo local (puerto 8069 abierto)
- [ ] ✅ Espacio en disco suficiente (3x tamaño BD)
- [ ] ✅ Master password correcta en `odoo.conf`
- [ ] ✅ PostgreSQL accesible
- [ ] ✅ Módulo copiado en addons_path
- [ ] ✅ Odoo reiniciado
- [ ] ✅ Módulo instalado desde interfaz Odoo

---

**Última actualización:** 23 Diciembre 2025

**Versión:** 1.0 Stable
