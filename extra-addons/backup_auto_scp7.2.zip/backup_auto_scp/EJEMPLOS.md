# 💡 EJEMPLOS REALES - Casos de Uso del Módulo

## 📌 Caso 1: Backup Local Simple (Mismo Servidor)

### Escenario
- 1 servidor con Odoo 17
- BD "empresa" de 150MB
- Descargar backup desde interfaz web

### Configuración

```yaml
Base de Datos:              empresa
Frecuencia:                 Manual
Modo de Backup:             Local Download
Formato de Descarga:        Completo (ZIP)

Host Odoo Local:            localhost
Puerto Odoo Local:          8069
Master Password:            admin123456

# SSH no es necesario
```

### Ejecución

1. En Odoo: `Backup Automático`
2. Botón: **⬇️ Descargar Backup**
3. Se descarga `backup_empresa_20251223_143022.zip` (~90MB comprimido)

### Resultado
✅ Archivo ZIP en la máquina cliente

---

## 📌 Caso 2: Backup Remoto Diario (Servidor Dedicado)

### Escenario
- Servidor A: Odoo 17 (157.180.32.7:8069)
- Servidor B: Storage remoto (192.168.1.100)
- BD "admin" de 800MB
- Backup automático cada 24 horas

### Configuración

```yaml
# Base de Datos
Base de Datos:              admin
Frecuencia:                 Diario  # Cada 24 horas
Modo de Backup:             Enviar a Servidor SSH
Formato de Descarga:        Completo (ZIP)

# Odoo Local (el que respaldar)
Host Odoo Local:            157.180.32.7
Puerto Odoo Local:          8069
Master Password:            C+UQYz9OKihLWPSZ

# SSH (donde guardar)
Servidor SSH:               192.168.1.100
Usuario SSH:                backup_user
Contraseña SSH:             MiContraseña123!
Ruta en Servidor:           /backups/odoo_prod
Ruta Clave SSH:             [vacío]
```

### Preparación del Servidor Remoto

```bash
# En servidor B (192.168.1.100)
sudo useradd -m backup_user
sudo mkdir -p /backups/odoo_prod
sudo chown backup_user:backup_user /backups/odoo_prod
sudo passwd backup_user  # MiContraseña123!

# Verificar
ls -la /backups/odoo_prod
```

### Ejecución

1. En Odoo (Servidor A): `Backup Automático`
2. Completar configuración SSH
3. Botón: **🔗 Probar Conexión** → ✅ Conexión exitosa
4. Botón: **📤 Enviar a SSH** (O esperar a que se ejecute automático cada 24h)
5. Esperar 45-60 minutos (transferencia de 800MB)

### Verificación

```bash
# En Servidor B
ssh backup_user@192.168.1.100

# Listar backups
ls -lh /backups/odoo_prod/
# Ejemplo output:
# backup_admin_20251223_010000.zip  505M
# backup_admin_20251222_010000.zip  505M
# backup_admin_20251221_010000.zip  505M

# Validar integridad del último
unzip -t /backups/odoo_prod/backup_admin_20251223_010000.zip | tail -5
# Resultado: "No errors detected in archive"
```

### Resultado
✅ Backups automáticos diarios guardados en servidor remoto

---

## 📌 Caso 3: Multi-Base de Datos

### Escenario
- 1 servidor Odoo 17 con 3 bases de datos
- `db_produccion` (1.2GB) → SSH a servidor remoto
- `db_testing` (500MB) → Descarga local
- `db_desarrollo` (150MB) → Manual bajo demanda

### Configuración 1: PRODUCCIÓN

```yaml
Base de Datos:              db_produccion
Frecuencia:                 8 Horas  # Cada 8 horas = 3 backups/día
Modo de Backup:             Enviar a Servidor SSH
Formato de Descarga:        Completo (ZIP)

Host Odoo Local:            localhost
Puerto Odoo Local:          8069
Master Password:            admin123456

Servidor SSH:               backup.empresa.com
Usuario SSH:                backup_prod
Contraseña SSH:             Prod123!@#
Ruta en Servidor:           /backups/prod
```

### Configuración 2: TESTING

```yaml
Base de Datos:              db_testing
Frecuencia:                 Diario
Modo de Backup:             Local Download
Formato de Descarga:        Completo (ZIP)

Host Odoo Local:            localhost
Puerto Odoo Local:          8069
Master Password:            admin123456

# SSH: No configurado
```

### Configuración 3: DESARROLLO

```yaml
Base de Datos:              db_desarrollo
Frecuencia:                 Manual
Modo de Backup:             Local Download
Formato de Descarga:        SQL Dump  # Más ligero

Host Odoo Local:            localhost
Puerto Odoo Local:          8069
Master Password:            admin123456
```

### Ejecución

```bash
# Producción: automático cada 8 horas
# Testing: automático cada 24 horas
# Desarrollo: bajo demanda con botón

# Monitorear todos en Odoo
# Aplicaciones → Backup Automático
# Ver estadísticas de cada base de datos
```

### Resultado
✅ 3 bases de datos respaldadas con diferentes estrategias

---

## 📌 Caso 4: Backup con Clave SSH (Máxima Seguridad)

### Escenario
- Servidor corporativo muy restrictivo
- Requiere autenticación con clave SSH
- Sin contraseñas en scripts

### Configuración

```yaml
Base de Datos:              admin
Frecuencia:                 Diario
Modo de Backup:             Enviar a Servidor SSH
Formato de Descarga:        Completo (ZIP)

Host Odoo Local:            localhost
Puerto Odoo Local:          8069
Master Password:            admin123456

Servidor SSH:               prod-backup.corp.local
Usuario SSH:                svc_backup
Contraseña SSH:             [VACÍO]
Ruta Clave SSH:             /root/.ssh/prod_backup_key
Ruta en Servidor:           /secure/backups
```

### Preparación de Clave SSH

```bash
# En servidor Odoo local
sudo mkdir -p /root/.ssh
sudo ssh-keygen -t rsa -b 4096 -N "" -f /root/.ssh/prod_backup_key

# Copiar clave pública al servidor remoto
cat /root/.ssh/prod_backup_key.pub | \
  ssh admin@prod-backup.corp.local 'cat >> /home/svc_backup/.ssh/authorized_keys'

# Verificar conectividad
ssh -i /root/.ssh/prod_backup_key svc_backup@prod-backup.corp.local "ls -la /secure/backups"
```

### Configuración en Odoo

- Poner ruta: `/root/.ssh/prod_backup_key`
- Dejar Contraseña SSH: **[VACÍO]**

### Ejecución
El módulo usará la clave SSH automáticamente sin pedir contraseña

### Resultado
✅ Backups seguros sin contraseñas en texto plano

---

## 📌 Caso 5: Restaurar desde Backup

### Escenario
Base de datos corrupta. Necesitas restaurar desde backup creado por el módulo.

### Pasos

```bash
# 1. En servidor remoto, descargar backup
scp backup_user@192.168.1.100:/backups/odoo_prod/backup_admin_20251223_010000.zip /tmp/

# 2. En servidor Odoo, crear directorio temporal
mkdir -p /tmp/restore
cd /tmp/restore

# 3. Extraer
unzip /tmp/backup_admin_20251223_010000.zip
# Produce:
# - dump.sql (base de datos)
# - filestore/ (archivos, imágenes, etc.)

# 4. Restaurar BD (parar Odoo primero)
sudo systemctl stop odoo

# 5. Crear BD nueva
sudo -u postgres psql -c "CREATE DATABASE admin_restore OWNER odoo;"

# 6. Restaurar dump
sudo -u postgres pg_restore -d admin_restore /tmp/restore/dump.sql

# 7. Cambiar nombre BD original (backup)
sudo -u postgres psql -c "ALTER DATABASE admin RENAME TO admin_backup_corrupted;"

# 8. Renombrar BD restaurada
sudo -u postgres psql -c "ALTER DATABASE admin_restore RENAME TO admin;"

# 9. Restaurar filestore
sudo cp -r /tmp/restore/filestore/* /var/lib/odoo/.local/share/Odoo/filestore/admin/

# 10. Asegurar permisos
sudo chown -R odoo:odoo /var/lib/odoo/.local/share/Odoo/filestore/admin/

# 11. Reiniciar Odoo
sudo systemctl start odoo

# 12. Verificar
# Acceder a Odoo y validar datos
```

### Resultado
✅ Base de datos restaurada desde backup

---

## 📌 Caso 6: Monitoreo y Alertas

### Escenario
Quieres asegurar que los backups se ejecutan correctamente

### Script de Monitoreo

```bash
#!/bin/bash
# backup_monitor.sh

BACKUP_PATH="/backups/odoo_prod"
EMAIL="admin@empresa.com"
MIN_SIZE=500000000  # 500MB mínimo

# Obtener último backup
LATEST=$(ls -t $BACKUP_PATH/*.zip 2>/dev/null | head -1)

if [ -z "$LATEST" ]; then
    echo "ERROR: No backup encontrado" | mail -s "⚠️ Backup fallido" $EMAIL
    exit 1
fi

# Verificar tamaño
SIZE=$(stat -f%z "$LATEST" 2>/dev/null || stat -c%s "$LATEST")

if [ $SIZE -lt $MIN_SIZE ]; then
    echo "ERROR: Backup muy pequeño ($SIZE bytes)" | mail -s "⚠️ Backup corrupto" $EMAIL
    exit 1
fi

# Verificar fecha (máximo 36 horas si es diario)
MTIME=$(stat -f%m "$LATEST" 2>/dev/null || stat -c%Y "$LATEST")
NOW=$(date +%s)
DIFF=$((NOW - MTIME))
MAX_AGE=$((36 * 3600))

if [ $DIFF -gt $MAX_AGE ]; then
    echo "ERROR: Backup muy antiguo ($(($DIFF / 3600)) horas)" | mail -s "⚠️ Backup no actualizado" $EMAIL
    exit 1
fi

# Validar integridad ZIP
unzip -t "$LATEST" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "ERROR: Backup corrupto" | mail -s "⚠️ ZIP inválido" $EMAIL
    exit 1
fi

echo "✅ Backup OK - $LATEST ($(($SIZE / 1000000))MB)" | mail -s "✅ Backup OK" $EMAIL
```

### Uso

```bash
# Ejecutar diariamente con cron
0 2 * * * /usr/local/bin/backup_monitor.sh
```

### Resultado
✅ Notificaciones automáticas si algo falla

---

## 📊 Comparativa de Casos

| Caso | Tamaño | Frecuencia | Destino | Tiempo | Confiabilidad |
|------|--------|-----------|---------|--------|---------------|
| 1: Local | 150MB | Manual | Local | 5 min | ⭐⭐⭐⭐⭐ |
| 2: Remoto | 800MB | Diario | SSH | 50 min | ⭐⭐⭐⭐⭐ |
| 3: Multi | Vario | Múltiple | Mixto | - | ⭐⭐⭐⭐⭐ |
| 4: Seguro | 800MB | Diario | SSH + clave | 50 min | ⭐⭐⭐⭐⭐ |
| 5: Restaurar | 500MB | Ad-hoc | N/A | 30 min | ⭐⭐⭐⭐⭐ |
| 6: Monitor | Vario | Diario | N/A | Auto | ⭐⭐⭐⭐⭐ |

---

## 📝 Logs de Ejemplo

### Backup Exitoso

```
2025-12-23 10:00:15 🚀 INICIANDO BACKUP SCP
2025-12-23 10:00:15 📥 CREANDO BACKUP PARA ENVIAR A SERVIDOR SSH
2025-12-23 10:00:15 🗄️ Base de datos: admin
2025-12-23 10:00:15 📂 Archivo temporal: /tmp/backup_admin_20251223_100015.zip
2025-12-23 10:00:15 📤 Destino remoto: 192.168.1.100:/backups/odoo_prod/backup_admin_20251223_100015.zip
2025-12-23 10:00:15 📝 Master Password: ****
2025-12-23 10:00:15 📥 Descargando backup ZIP...
2025-12-23 10:47:32 📊 Curl return code: 0
2025-12-23 10:47:32 ✅ Backup descargado: 526385152 bytes
2025-12-23 10:47:32 ✅ Validación ZIP correcta - Primeros bytes: b'PK\x03\x04'
2025-12-23 10:47:32 📏 Tamaño: 501.96 MB
2025-12-23 10:47:32 📤 ENVIANDO A SERVIDOR SSH...
2025-12-23 10:47:32 🖥️ Servidor: backup_user@192.168.1.100:/backups/odoo_prod
2025-12-23 10:47:32 📁 Creando directorio remoto...
2025-12-23 10:47:34 ⏳ Transferiendo archivo (esto puede tardar varios minutos)...
2025-12-23 10:47:34 📊 Tamaño a transferir: 501.96 MB
2025-12-23 10:48:45 ✅ Archivo enviado exitosamente
2025-12-23 10:48:46 📊 Información remota: -rw-r--r-- 1 backup_user 526385152 backup_admin_20251223_100015.zip
2025-12-23 10:48:46 🗑️ Archivo temporal eliminado
2025-12-23 10:48:46 🎉 BACKUP SCP COMPLETADO EXITOSAMENTE
2025-12-23 10:48:46 📊 Tamaño local: 501.96 MB
2025-12-23 10:48:46 📊 Tamaño remoto: 501.96 MB
```

### Backup con Error

```
2025-12-23 14:00:15 🚀 INICIANDO BACKUP SCP
...
2025-12-23 14:09:32 ❌ Error: El archivo descargado es HTML o muy pequeño
2025-12-23 14:09:32 ❌ Error descargando backup. Verifica master_password
```

---

**Última actualización:** 23 Diciembre 2025

**Versión:** 1.0 Stable
