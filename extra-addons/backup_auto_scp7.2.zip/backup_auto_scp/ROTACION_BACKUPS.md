# 🔄 ROTACIÓN DE BACKUPS - Sistema de Sobrescritura

## 📌 Problema Resuelto

**Escenario:** 30 servidores Odoo, cada uno generando backups automáticos diarios.

**Problema original:** Los archivos se acumulaban con timestamps, llenando el disco:
```
backup_admin_20251223_100000.zip  500MB
backup_admin_20251223_120000.zip  500MB
backup_admin_20251223_140000.zip  500MB
...
backup_admin_20251223_220000.zip  500MB

# Total después de 30 días = 15GB+ (¡Disco lleno!)
```

**Solución implementada:** Sobrescritura con nombres fijos (sin timestamp)

---

## ✅ Sistema de Rotación Implementado

### Nombres de Archivo (NUEVO)

```
ANTES (con timestamp):
  backup_admin_20251223_100000.zip
  backup_admin_20251223_120000.zip
  backup_admin_20251223_140000.zip
  → Nunca se sobrescriben

DESPUÉS (sin timestamp):
  backup_admin.zip
  backup_empresa.zip
  backup_produccion.zip
  → Cada nuevo backup sobrescribe el anterior
```

### Ahorro de Espacio

| Escenario | Archivos | Espacio | Frecuencia |
|-----------|----------|---------|-----------|
| **1 servidor, diario** | 1 | 500MB | ÓPTIMO ✅ |
| **30 servidores, diario** | 30 | 15GB | ÓPTIMO ✅ |
| **30 servidores, 8h** | 30 | 15GB | ÓPTIMO ✅ |
| **100 servidores, diario** | 100 | 50GB | ÓPTIMO ✅ |

---

## 🔧 Implementación Técnica

### Cambios en el código

```python
# ANTES (línea 270):
backup_filename = f"backup_{self.database_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"

# DESPUÉS (línea 270):
backup_filename = f"backup_{self.database_name}.zip"
```

**Afecta a 3 métodos:**

1. `_execute_backup_scp()` - Envío a SSH
   ```python
   backup_filename = f"backup_{self.database_name}.zip"
   ```

2. `_execute_backup_sql()` - SQL Dump
   ```python
   backup_filename = f"backup_{self.database_name}.sql"
   ```

3. `_execute_backup_local()` - Backup local
   ```python
   backup_filename = f"backup_{self.database_name}.zip"
   ```

---

## 🚀 Comportamiento Resultante

### Ejemplo 1: Servidor con 3 bases de datos

```
Hora 10:00 - Primer backup
/backups/
  backup_admin.zip           (500MB)
  backup_produccion.zip      (800MB)
  backup_pruebas.zip         (200MB)
  Total: 1.5GB

Hora 12:00 - Segundo backup
/backups/
  backup_admin.zip           (500MB) ← SOBRESCRITO
  backup_produccion.zip      (800MB) ← SOBRESCRITO
  backup_pruebas.zip         (200MB) ← SOBRESCRITO
  Total: 1.5GB (sin cambios)

Después de 30 días:
  Total: Siempre 1.5GB ✅
```

### Ejemplo 2: 30 Odoos en un servidor central

```
Servidor backup central: /home/backup/odoos/

backup_odoo1.zip         500MB  ← Actualizado cada 24h
backup_odoo2.zip         480MB  ← Actualizado cada 24h
backup_odoo3.zip         520MB  ← Actualizado cada 24h
...
backup_odoo30.zip        510MB  ← Actualizado cada 24h

Total: ~15GB (FIJO)
Nunca aumenta ✅
```

---

## 📊 Ventajas del Sistema

| Ventaja | Beneficio | Impacto |
|---------|-----------|--------|
| **Sin acumulación** | Espacio predecible | ✅ Discos no se llenan |
| **Simple** | Fácil de entender | ✅ Mantenimiento bajo |
| **Determinista** | Siempre el archivo más reciente | ✅ Sin confusiones |
| **Escalable** | Funciona con N servidores | ✅ Para 30, 100, 1000 Odoos |
| **Automático** | No requiere limpieza | ✅ Sin intervención manual |

---

## ⚠️ Consideraciones Importantes

### ✅ Qué pasa correctamente

- ✅ El último backup siempre está disponible
- ✅ Se sobrescribe automáticamente cada vez
- ✅ No hay confusión de versiones
- ✅ Espacio total fijo

### ⚠️ Qué cambia

- ❌ **NO hay histórico** de backups anteriores
  - Si el último backup falla y lo sobrescribe con error, no tienes respaldo
- ❌ **NO puedes comparar versiones** de 3 días atrás vs hoy
- ❌ **NO hay punto-en-tiempo-recovery** (solo el último)

---

## 🛡️ Riesgo Mitigado

### Problema: "¿Qué pasa si se corrompe el backup?"

**Antes:** Quedabas sin backup = Punto muerto
**Después:** Mismo riesgo, pero:
- El último backup existente fue validado (ZIP check)
- La próxima ejecución lo sobrescribe con uno nuevo

**Recomendación:** Ejecuta `action_backup_manual()` cada vez que hagas cambios críticos en Odoo

---

## 🚀 Monitoreo Recomendado

### Verificar que la rotación funciona

```bash
# En el servidor de backup
watch -n 3600 'ls -lh /home/backup/odoos/ | tail -10'

# O ver cambios de tamaño
while true; do
  echo "=== $(date) ==="
  du -sh /home/backup/odoos/backup_*.zip | sort -h
  sleep 3600  # Cada hora
done
```

### Alertas (Opcional)

```bash
#!/bin/bash
# Si un backup NO cambia en 48 horas, alertar

BACKUP_FILE="/home/backup/odoos/backup_admin.zip"
MTIME=$(stat -c%Y "$BACKUP_FILE")
NOW=$(date +%s)
AGE=$((NOW - MTIME))
MAX_AGE=$((48 * 3600))  # 48 horas

if [ $AGE -gt $MAX_AGE ]; then
    echo "⚠️ ALERTA: backup_admin.zip no se actualiza hace $(($AGE / 3600)) horas"
fi
```

---

## 📝 Cambios en la Documentación Necesarios

Para próximos usuarios, documenta:

```markdown
## 🔄 Sistema de Rotación

El módulo utiliza **sobrescritura automática** para prevenir 
saturación de disco. Cada base de datos mantiene **UN ÚNICO ARCHIVO** 
que se actualiza con cada backup.

Nombres de archivo:
- backup_admin.zip
- backup_produccion.zip
- backup_pruebas.sql

Espacio total = Suma de todos los backups (nunca crece)
```

---

## ✨ Ventajas para tu Caso (30 Odoos)

| Aspecto | Beneficio |
|--------|-----------|
| **Espacio** | 15GB fijo en lugar de ilimitado |
| **Administración** | Sin limpieza manual |
| **Confiabilidad** | Siempre el backup más reciente |
| **Backup de backup** | Puedes hacer copia a NAS/Cloud del archivo final |
| **Escalabilidad** | Agregá 50 Odoos más sin problema |

---

## 🎯 Próximas Mejoras Posibles

- 🔲 Opción de rotación (guardar últimos N backups)
- 🔲 Compresión incremental (solo cambios)
- 🔲 Backup a múltiples destinos
- 🔲 Notificaciones si el backup falla

---

**Última actualización:** 23 Diciembre 2025

**Implementado en:** v1.0 del módulo

**Status:** ✅ Producción
