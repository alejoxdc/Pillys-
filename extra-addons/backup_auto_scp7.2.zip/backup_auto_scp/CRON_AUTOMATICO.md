# ⏰ GUÍA DE CRON AUTOMÁTICO - Backups en Bucle

## 🎯 ¿Cómo Funciona?

Ahora el módulo tiene **2 cron jobs** que se ejecutan automáticamente sin intervención del usuario:

```
CRON 1: Cada 8 horas
CRON 2: Cada 24 horas (diario)

Ambos ejecutan: cron_auto_backup()
↓
Busca configuración ACTIVA
↓
Ejecuta backup según modo configurado
↓
Actualiza última fecha y resultado
↓
Reprogramma próximo backup
↓
BUCLE AUTOMÁTICO ♻️
```

---

## 📋 Flujo Completo

### 1️⃣ Usuario configura backup

```
Administración → Backup Automático
├─ Base de Datos: admin
├─ Frecuencia: Cada 8 horas (o Diario)
├─ Modo: Enviar a Servidor SSH (o Local)
├─ Configuración Odoo Local
└─ Configuración SSH
```

### 2️⃣ Usuario presiona ACTIVAR

```
Estado: DRAFT → ACTIVE
↓
Se ejecuta: action_activate()
↓
Se programa: next_backup_date
↓
Cron queda listo para ejecutar
```

### 3️⃣ Cron se ejecuta automáticamente

**Cada 8 horas o cada día (según configurado):**

```
⏰ Cron timer dispara
        ↓
✅ cron_auto_backup() se ejecuta
        ↓
🔍 Busca: backup.auto.scp with state='active'
        ↓
📤 Ejecuta: _execute_backup_scp()
           _execute_backup_local()
           o ambas
        ↓
✅ Actualiza: last_backup_date
             backup_count
             last_backup_result
             last_backup_file
        ↓
🔄 Llama: _schedule_next_backup()
        ↓
⏰ Cron se vuelve a ejecutar en 8h/24h
        ↓
♻️ BUCLE INFINITO
```

---

## 🔧 Configuración del Cron

### Dónde está configurado

Archivo: `data/cron.xml`

```xml
<!-- CRON: Backup cada 8 horas -->
<record id="cron_backup_8_hours" model="ir.cron">
    <field name="name">Backup Automático cada 8 horas</field>
    <field name="model_id" ref="model_backup_auto_scp"/>
    <field name="state">code</field>
    <field name="code">env['backup.auto.scp'].cron_auto_backup()</field>
    
    <!-- PARÁMETROS CLAVE -->
    <field name="interval_number">8</field>      <!-- Cada 8 -->
    <field name="interval_type">hours</field>    <!-- horas -->
    <field name="numbercall">-1</field>          <!-- -1 = infinito -->
    <field name="active" eval="True"/>           <!-- Siempre activo -->
    <field name="doall" eval="False"/>           <!-- No ejecutar múltiples -->
    <field name="nextcall">2025-12-24 00:00:00</field> <!-- Primera ejecución -->
</record>
```

### Parámetros explicados

| Parámetro | Valor | Significado |
|-----------|-------|-------------|
| `interval_number` | 8 | Cada 8... |
| `interval_type` | hours | ...horas |
| `numbercall` | -1 | Ejecutar infinitamente (-1 = sin límite) |
| `active` | True | El cron siempre está habilitado |
| `doall` | False | Si se retrasa, NO ejecutar múltiples veces |
| `nextcall` | DATETIME | Fecha/hora de la próxima ejecución |

---

## 🚀 Cómo Funciona en Detalle

### Paso 1: Instalación del módulo

```
$ odoo update backup_auto_scp
↓
- Se crea tabla backup_auto_scp
- Se cargan datos de cron.xml
- Se crean 2 records en ir.cron
- Cron queda listo pero NO ejecuta (porque no hay config activa)
```

### Paso 2: Usuario crea configuración

```
Crear nuevo Backup Automático
├─ database_name: admin
├─ server_host: 157.180.32.7
├─ server_user: backup_user
├─ server_password: ***
├─ server_path: /home/backups
├─ backup_frequency: "8_hours"
├─ backup_mode: "remote_scp"
└─ state: "draft"
```

### Paso 3: Usuario presiona ACTIVAR

```
Acción: action_activate()
├─ Cambia state: draft → active
├─ Calcula: next_backup_date = now() + 8 horas
└─ Guarda cambios

Resultado:
✅ Estado = ACTIVE
✅ Próximo: 2025-12-24 23:00:00
```

### Paso 4: Cron espera y ejecuta

```
⏰ 2025-12-24 23:00:00 → Cron dispara
        ↓
env['backup.auto.scp'].cron_auto_backup()
        ↓
Busca: self.search([('state', '=', 'active')], limit=1)
        ↓
Encontró configuración activa ✅
        ↓
Ejecuta: _execute_backup_scp()
        ├─ Descarga ZIP desde localhost:8069
        ├─ Valida integridad (magic bytes)
        ├─ Envía por SCP a servidor remoto
        ├─ Verifica en servidor
        └─ Actualiza registros
        ↓
✅ last_backup_result = "✅ Backup exitoso..."
✅ backup_count = 1
✅ last_backup_date = 2025-12-24 23:00:00
✅ last_backup_file = "backup_admin.zip"
✅ last_backup_size = "501.96 MB"
```

### Paso 5: Siguiente ejecución

```
_schedule_next_backup() calcula:
next_backup_date = now() + 8 horas
                 = 2025-12-25 07:00:00
                 
Cron vuelve a ejecutarse en 8 horas
↓
♻️ BUCLE CONTINÚA INFINITAMENTE
```

---

## 📊 Ejemplo de Timeline

```
23:00 → Cron ejecuta 1er backup
        ✅ Resultado: EXITOSO

07:00 → Cron ejecuta 2do backup
        ✅ Resultado: EXITOSO
        
15:00 → Cron ejecuta 3er backup
        ✅ Resultado: EXITOSO
        
23:00 → Cron ejecuta 4to backup
        ✅ Resultado: EXITOSO
        
... (continúa cada 8 horas)
```

---

## 🛑 Cómo Detener los Backups

### Opción 1: Desactivar desde interfaz

```
Backup Automático → Seleccionar → Botón "⏹️ Desactivar"
↓
estado: active → inactive
↓
Cron sigue ejecutándose pero NO hace nada (busca active=true)
↓
✅ Backups detenidos
```

### Opción 2: Desactivar cron desde Admin

```
Administración → Tareas Programadas (ir.cron)
├─ "Backup Automático cada 8 horas" → Desactivar
└─ "Backup Automático Diario" → Desactivar
↓
✅ Cron no se ejecuta más
```

---

## 🔍 Monitorear Ejecuciones

### Ver logs en tiempo real

```bash
# En terminal donde corre Odoo
tail -f /var/log/odoo/odoo.log | grep -E "🕐|🚀|✅|❌"

# Ejemplo output:
# 2025-12-24 23:00:00 🕐 EJECUTANDO CRON DE BACKUP AUTOMÁTICO
# 2025-12-24 23:00:00 🚀 INICIANDO BACKUP SCP
# 2025-12-24 23:47:30 ✅ Backup ZIP enviado exitosamente
```

### Ver en interfaz Odoo

```
Backup Automático → Última ejecución
├─ last_backup_date: 2025-12-24 23:47:30
├─ backup_count: 5
├─ last_backup_result: ✅ Backup ZIP enviado exitosamente
├─ last_backup_size: 501.96 MB
└─ last_backup_file: backup_admin.zip
```

### Ver en base de datos

```sql
SELECT 
    id,
    database_name,
    state,
    last_backup_date,
    backup_count,
    last_backup_result,
    TIMESTAMP 'now'() - last_backup_date AS last_backup_age
FROM backup_auto_scp
WHERE state = 'active'
ORDER BY last_backup_date DESC;
```

---

## ⚙️ Ajustes Avanzados

### Cambiar frecuencia

En la interfaz:
```
backup_frequency: 8_hours → daily
    (Cambiar de cada 8h a diario)
```

El cron sigue ejecutándose, pero ahora el método `_schedule_next_backup()` calcula:
```
next_backup_date = now() + 24 horas (en lugar de 8)
```

### Cambiar tiempo de ejecución

Si quieres que se ejecute a las 3:00 AM todos los días:

```sql
UPDATE ir_cron 
SET nextcall = '2025-12-25 03:00:00'
WHERE name LIKE '%Backup%';
```

Odoo ejecutará el cron a esa hora, y luego cada 24 horas después.

### Ejecutar múltiples backups

Si tienes 30 Odoos diferentes, crea 30 configuraciones:

```
Backup 1: backup.auto.scp #1 → database_name = odoo1
Backup 2: backup.auto.scp #2 → database_name = odoo2
...
Backup 30: backup.auto.scp #30 → database_name = odoo30
```

El cron ejecutará el primero activo que encuentre. Para ejecutar TODOS:

Modifica `cron_auto_backup()` para buscar todos:

```python
@api.model
def cron_auto_backup(self):
    """Ejecutar TODOS los backups activos"""
    active_backups = self.search([('state', '=', 'active')])
    for backup in active_backups:
        try:
            if backup.backup_mode == 'remote_scp':
                backup._execute_backup_scp()
            # ... etc
        except Exception as e:
            _logger.error("Error en %s: %s", backup.name, str(e))
```

---

## 🆘 Troubleshooting

### El cron no se ejecuta

**Síntomas:**
- `last_backup_date` no cambia
- No hay logs de "🕐 EJECUTANDO CRON"

**Soluciones:**
1. Verificar que `state = 'active'`
2. Verificar que cron está habilitado:
   - Administración → Tareas Programadas
   - Ver que "Backup Automático..." tiene ✅ Activo
3. Reiniciar Odoo:
   ```bash
   pkill -f odoo-bin
   ./odoo-bin -c odoo.conf
   ```
4. Verificar fecha en servidor:
   ```bash
   date
   # Debe estar correcta
   ```

### El cron se ejecuta pero falla

**Síntomas:**
- `last_backup_result` = "❌ Error..."
- `last_backup_size` = "Error"

**Soluciones:**
1. Revisar `last_backup_result` (mensaje de error específico)
2. Verificar logs:
   ```bash
   tail -50 /var/log/odoo/odoo.log | grep -A5 "❌"
   ```
3. Verificar configuración:
   - ¿Master password correcta?
   - ¿SSH accesible?
   - ¿Espacio en disco?

---

## 📈 Estadísticas

Ejemplo después de 30 días con backups cada 8 horas:

```
Configuración: backup_admin
├─ last_backup_date: 2025-01-24 15:00:00
├─ backup_count: 90  (30 días × 3 backups/día)
├─ last_backup_result: ✅ Exitoso
├─ last_backup_size: 501.96 MB
└─ last_backup_file: backup_admin.zip

Espacio en servidor:
├─ Archivos guardados: 1 (siempre sobrescribido)
├─ Tamaño total: 501.96 MB
└─ Espacio utilizado: ~0.5 GB (óptimo)
```

---

## ✅ Checklist de Configuración

- [ ] ✅ Módulo `backup_auto_scp` instalado
- [ ] ✅ Cron jobs creados (ver Tareas Programadas)
- [ ] ✅ Backup configurado con `state = 'active'`
- [ ] ✅ `backup_frequency` = `8_hours` o `daily`
- [ ] ✅ SSH/servidor remoto configurado correctamente
- [ ] ✅ Master password verificada
- [ ] ✅ Primer backup ejecutado exitosamente
- [ ] ✅ Logs muestran ejecuciones automáticas
- [ ] ✅ Archivo se sobrescribe en servidor (no se acumula)

---

**Última actualización:** 24 Diciembre 2025

**Versión:** 1.1 (con Cron automático)
