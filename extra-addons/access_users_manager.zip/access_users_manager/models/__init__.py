# -*- coding: utf-8 -*-

from . import access_user_manager
from . import access_res_users
from . import access_get_views
from . import access_model_access
from . import access_field_access
from . import access_domain_access
from . import access_button_tab_access
from . import access_filter_group_access
from . import access_menu
from . import access_view
from . import access_actions

from . import access_res_users
from . import access_user_profiles
from . import access_res_groups

from . import access_recent_activity
from . import access_res_config_setting
from . import access_uninstall_module



