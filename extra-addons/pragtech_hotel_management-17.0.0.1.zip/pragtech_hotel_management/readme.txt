Note:
@@@Please copy and install  all modules from pragtech_hotel_management_addons directory@@
