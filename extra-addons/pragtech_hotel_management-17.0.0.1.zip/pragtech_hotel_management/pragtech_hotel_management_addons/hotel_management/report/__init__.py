# -*- encoding: utf-8 -*-

from . import hotel_folio_report
from . import hotel_reservation_report
from . import room_guestwise_report
from . import monthly_occupency_report
from . import report_arrival_depart_guestwise_data

#vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
