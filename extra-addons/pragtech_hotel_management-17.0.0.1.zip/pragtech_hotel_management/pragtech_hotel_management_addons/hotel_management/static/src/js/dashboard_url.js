var url_for_dashboard = "";

openerp.hotel_management = function(instance){
	
	//instance.hotel_management = {};
	//alert("In url test init");
	//console.log(instance);
	//inst_var=new instance.web.DataSet(this,'res.partner',{});
	//console.log(inst_var);
	//new instance.web.DataSetSearch(this,'res.partner',{},[]).read_slice(['name'],null).done(function(res){
	//	url_for_dashboard = res[0].name;
	//	console.log("**************RES****************");
	//	console.log(res);
	//});
	
};
