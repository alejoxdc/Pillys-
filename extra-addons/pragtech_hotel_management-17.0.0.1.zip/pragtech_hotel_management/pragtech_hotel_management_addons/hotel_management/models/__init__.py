# -*- encoding: utf-8 -*-

from . import sale
from . import hotel_management
from . import hotel_housekeeping
from . import agent_commission
from . import res_config
from . import ir_config_setting


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
